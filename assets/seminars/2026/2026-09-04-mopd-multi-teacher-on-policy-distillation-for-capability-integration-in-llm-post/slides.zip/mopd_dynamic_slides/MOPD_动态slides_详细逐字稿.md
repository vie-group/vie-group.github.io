# MOPD 组会扩写逐字稿

说明：本版按最终动态 slides 逐页重写。每页都覆盖页面可见文字、图表/公式含义、讲解顺序和页间衔接。讲稿保留必要英文术语，但优先使用中文解释。

## Slide 1: MOPD：多教师在线策略（on-policy）蒸馏（Multi-Teacher On-Policy Distillation）

### 页面内容覆盖
- 论文精读 · arXiv:2606.30406v1 MOPD Multi-Teacher
- On-Policy Distillation for Capability Integration in LLM Post-Training Peking University / Xiaomi LLM Core · 组会汇报版

### 扩写讲稿
开场先把主题放稳：这次汇报围绕「MOPD：多教师在线策略（on-policy）蒸馏（Multi-Teacher On-Policy Distillation）」展开。
论文定位：
题目里的 MOPD 是 Multi-Teacher On-Policy Distillation，研究的是 LLM post-training 阶段的“多能力集成（capability integration）”问题。
现代大模型通常在后训练阶段针对数学、代码、指令跟随、搜索等能力分别做强化学习。
论文的核心观察是：单域 RL teacher 可以很强，最终目标是得到一个统一模型，集中吸收这些领域专家的能力。
MOPD 的答案是：先得到多个领域 RL teacher，再让 student 在自己的采样轨迹（rollouts）上接受这些 teacher 的 token-level 指导。
今天汇报重点是这个流程如何同时做到 dense optimization、on-policy 和可并行。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
展开页面内容时，可以按这个顺序讲：论文精读 · arXiv:2606.30406v1 MOPD Multi-Teacher；On-Policy Distillation for Capability Integration in LLM Post-Training Peking University / Xiaomi LLM Core · 组会汇报版。## Slide 2: 汇报路线

### 页面内容覆盖
- Agenda 汇报路线 按论文顺序展开，方法部分逐步拆解 01 引言 能力集成（capability integration）问题 02 相关工作 强化学习 / 蒸馏 / 合并 03 方法 三阶段 + 两种损失 + 工程实现 04 实验 Qwen3 与 MiMo-V2-Flash 05 分析 同源教师（same-origin teacher）与多轮演化 06 讨论 工程价值与讨论点

### 扩写讲稿
汇报路线从问题动机进入方法、实验、分析，再到论文写作结构。
我会严格按论文顺序走，先讲 Introduction 中提出的 capability integration 问题，再讲 Related Work 中作者如何对比 RL、distillation 和 model merging。
主体是 Method 部分，我会拆成三阶段 pipeline、Stage 3 的单步流程、在线蒸馏（on-policy distillation）的稳定性护栏、反向 KL（Reverse KL）目标、policy-gradient 实现、Top-k 实现以及 teacher prefill 的工程设计。
实验部分先讲 controlled setting 下 Qwen3-30B-A3B 的主结果，再讲 MiMo-V2-Flash 的工业规模验证。
最后是三个分析：PG 与 Top-k、same-origin teacher 的稳定性、多轮 student-teacher evolution。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：Agenda 汇报路线 按论文顺序展开，方法部分逐步拆解 01 引言 能力集成（capability integration）问题 02 相关工作 强化学习 / 蒸馏 / 合并 03 方法 三阶段 + 两种损失 + 工程实现 04 实验 Qwen3 与 MiMo-V2-Flash 05 分析 同源教师（same-origin teacher）与多轮演化 06 讨论 工程价值与讨论点。## Slide 3: 1. 引言

### 页面内容覆盖
- 为什么需要 MOPD？ 1. 引言 接下来按论文顺序展开这一部分。

### 扩写讲稿
进入背景部分。

展开页面内容时，可以按这个顺序讲：为什么需要 MOPD？ 1. 引言 接下来按论文顺序展开这一部分。。## Slide 4: 问题：多个 RL 能力如何合到一个模型？

### 页面内容覆盖
- 引言 问题：多个强化学习能力如何合到一个模型？ 领域 数学 可验证答案强化学习 领域 软件工程 沙箱代理强化学习 领域 指令跟随 规则评审式强化学习 领域 搜索 网页环境强化学习 目标 一个统一模型，同时继承多个领域专家能力

### 扩写讲稿
论文开头从一个很现实的问题出发：不同能力已经有不同的 RL 训练范式。
数学推理可以用可验证答案的 RLVR，软件工程可以在可执行 sandbox 里做 agent-style RL，指令跟随和创意写作可以用 rubric-based reward，搜索任务又需要 web-environment RL。
这些 pipeline 的共同点是：它们通常能把目标领域做强。
产品和通用模型需要一个模型同时具备这些能力。
直接把所有任务混在一起训、逐个领域级联训练、离线模仿 teacher、或者合并参数，都会遇到效率、稳定性或性能损失。
所以作者把问题定义为 capability integration，研究多能力进入同一个模型的过程。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：引言 问题：多个强化学习能力如何合到一个模型？ 领域 数学 可验证答案强化学习 领域 软件工程 沙箱代理强化学习 领域 指令跟随 规则评审式强化学习 领域 搜索 网页环境强化学习 目标 一个统一模型，同时继承多个领域专家能力。## Slide 5: 现有路线的三角约束

### 页面内容覆盖
- 引言 现有路线的三角约束 三个实践维度：稠密信号、在线策略（on-policy）、并行化 方法 稠密信号 在线策略（on-policy）可并行 Param-Merge × — ✓ Off-Policy FT ✓ × ✓ Mix-RL × ✓ × Cascade RL × ✓ × MOPD ✓ ✓ ✓ MOPD 是表中唯一同时满足三项的方法。

### 扩写讲稿
这张表是论文动机的核心。
作者把已有方法放到三个维度上比较：第一，dense optimization，意思是训练信号是否足够密集；第二，on-policy，意思是训练时是否在 student 自己会访问到的分布上；第三，parallelisable，意思是多领域能力生产是否能并行。
Param-Merge 可以并行，因为各 teacher 独立训练后合并参数，它缺少训练意义上的 dense/on-policy 属性。
Off-Policy Finetune 有 dense supervision，因为能用 teacher trajectories 上的 token-level 信息，student 训练时看到的是 teacher 轨迹。
Mix-RL 和 Cascade RL 是 on-policy，主要依赖 outcome reward，信号稀疏，训练过程强耦合。
MOPD 的设计目标就是同时拿到这三项。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
展开页面内容时，可以按这个顺序讲：引言 现有路线的三角约束 三个实践维度：稠密信号、在线策略（on-policy）、并行化 方法 稠密信号 在线策略（on-policy）可并行 Param-Merge × — ✓ Off-Policy FT ✓ × ✓ Mix-RL × ✓ × Cascade RL × ✓ × MOPD ✓ ✓ ✓ MOPD 是表中唯一同时满足三项的方法。。## Slide 6: MOPD 的核心答案

### 页面内容覆盖
- 引言 MOPD 的核心答案 同源 teacher 并行生产；student 自己的采样轨迹（rollout）；teacher 逐 token 打分。
- 在线策略（on-policy）降低暴露偏差（exposure bias）训练轨迹来自学生模型自己，训练/推理状态分布更接近。
- 逐 token 稠密信号 每个 token 都有教师对数概率，信号密度高于整条轨迹奖励。
- 路由 策略空间融合（policy-space fusion）按问题领域路由教师，避免权重空间（weight space）直接融合。

### 扩写讲稿
可以用这句话概括 MOPD：同源 teacher 并行生产，student 自己的采样轨迹（rollout），teacher 逐 token 打分。
这里每个词都重要。
“同源”是指 teacher 和 student 都从同一个 SFT checkpoint 出发，这会影响后面 same-origin 稳定性。
“并行生产”是指每个领域 teacher 可以独立做自己的 RL。
“student 自己的采样轨迹（rollout）”对应 on-policy，避免 off-policy imitation 的 exposure bias。
“逐 token 打分”对应 dense signal，teacher 在每个 token 前缀上给概率分布或 top-k logits，提供比最终 reward 更密集的信号。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：引言 MOPD 的核心答案 同源 teacher 并行生产；student 自己的采样轨迹（rollout）；teacher 逐 token 打分。；在线策略（on-policy）降低暴露偏差（exposure bias）训练轨迹来自学生模型自己，训练/推理状态分布更接近。；逐 token 稠密信号 每个 token 都有教师对数概率，信号密度高于整条轨迹奖励。；路由 策略空间融合（policy-space fusion）按问题领域路由教师，避免权重空间（weight space）直接融合。。## Slide 7: 澄清：策略空间融合（policy-space fusion）为什么关键？

### 页面内容覆盖
- 引言澄清 澄清：策略空间融合（policy-space fusion）为什么关键？ 融合发生在学生模型的生成行为上 参数 权重空间（weight space）直接合并参数 θ，容易遇到参数冲突与合并系数敏感。
- 数据 答案空间 模仿教师完整答案，训练状态落在教师轨迹上。
- 行为 策略空间 学生自己生成；教师在同一前缀下给 token 分布信号。
- 看这三个箭头的区别：参数合并改权重，离线蒸馏（off-policy distillation）学教师写过的答案，MOPD 直接修正学生自己会走到的逐 token 决策。

### 扩写讲稿
策略空间融合（policy-space fusion）的价值在于直接对齐部署时的 token 决策。
语言模型最终部署时真正发生的是逐 token 决策，所以融合最好落在每个前缀下的 token distribution 上。
MOPD 让 student 先走自己的轨迹，再由领域 teacher 在这些状态上提供概率指导。
这样既绕开 weight-space 参数冲突，也减少离线 teacher trajectory imitation 的状态错位。

展开页面内容时，可以按这个顺序讲：引言澄清 澄清：策略空间融合（policy-space fusion）为什么关键？ 融合发生在学生模型的生成行为上 参数 权重空间（weight space）直接合并参数 θ，容易遇到参数冲突与合并系数敏感。；数据 答案空间 模仿教师完整答案，训练状态落在教师轨迹上。；行为 策略空间 学生自己生成；教师在同一前缀下给 token 分布信号。；看这三个箭头的区别：参数合并改权重，离线蒸馏（off-policy distillation）学教师写过的答案，MOPD 直接修正学生自己会走到的逐 token 决策。。## Slide 8: MOPD 的五个结构性优势

### 页面内容覆盖
- 引言 → 方法 论文声明的五个结构性优势 这是 §3.1 末尾对 MOPD 的完整技术定位 1 降低暴露偏差（exposure bias）学生在自己的采样轨迹（rollout）分布上训练，训练/推理状态分布更接近。
- 2 逐 token 稠密监督 教师在每个 token 位置提供概率分布，比轨迹级奖励更密集、低方差。
- 3 策略空间集成（policy-space integration）通过问题领域路由对齐领域教师，不做权重平均或任务向量合并。
- 4 模块化并行教师 每个教师独立训练、独立调参、可并行执行。
- 5 同源稳定性（same-origin stability）教师与学生来自同一 SFT checkpoint，初始 KL 低，蒸馏更平滑。

### 扩写讲稿
这里补全论文 §3.1 对 MOPD 的五个结构性优势。
这里把 exposure bias 表述成 reduced，强调 MOPD 的作用是缓解 teacher-forcing 式状态错位。
重点是：student 在自己的采样轨迹（rollout）分布上训练，teacher 在这些状态上给 dense token supervision，多个 teacher 通过 policy-space 路由完成能力集成（capability integration）。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：引言 → 方法 论文声明的五个结构性优势 这是 §3.1 末尾对 MOPD 的完整技术定位 1 降低暴露偏差（exposure bias）学生在自己的采样轨迹（rollout）分布上训练，训练/推理状态分布更接近。；2 逐 token 稠密监督 教师在每个 token 位置提供概率分布，比轨迹级奖励更密集、低方差。；3 策略空间集成（policy-space integration）通过问题领域路由对齐领域教师，不做权重平均或任务向量合并。；4 模块化并行教师 每个教师独立训练、独立调参、可并行执行。；5 同源稳定性（same-origin stability）教师与学生来自同一 SFT checkpoint，初始 KL 低，蒸馏更平滑。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 2: 2. 相关工作

### 页面内容覆盖
- MOPD 站在哪些工作之间？ 2. 相关工作 接下来按论文顺序展开这一部分。

### 扩写讲稿
进入相关工作部分。

展开页面内容时，可以按这个顺序讲：MOPD 站在哪些工作之间？ 2. 相关工作 接下来按论文顺序展开这一部分。。## Slide 10: 相关工作位置

### 页面内容覆盖
- 相关工作 相关工作位置 大模型强化学习 单领域专家：数学 / 软件工程 / 指令跟随 / 搜索 蒸馏 离线固定语料 → 在线教师评分 模型合并 权重空间融合（weight-space merging），可能出现参数冲突 MOPD multi-teacher · prompt-routed · on-policy

### 扩写讲稿
相关工作可以分三条线讲。
第一条是 RL for LLM：论文指出当前数学、SWE、IF、搜索等能力已经形成了不同的 RL pipeline，每条 pipeline 都能产生强 domain expert。
第二条是 distillation：经典蒸馏通常在 teacher 的固定输出语料上做 forward KL 或 SFT，因此是 off-policy；on-policy distillation 则让 student 自己采样，teacher 负责打分。
第三条是 model merging，例如 model soup、task arithmetic、TIES、DARE 等，它们试图在权重空间融合（weight-space merging）能力。
MOPD 和它们的区别是：它在 policy space 中使用 prompt-routed multi-teacher on-policy distillation 做能力集成（capability integration），避开 weight-space 合并和 static dataset imitation。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
展开页面内容时，可以按这个顺序讲：相关工作 相关工作位置 大模型强化学习 单领域专家：数学 / 软件工程 / 指令跟随 / 搜索 蒸馏 离线固定语料 → 在线教师评分 模型合并 权重空间融合（weight-space merging），可能出现参数冲突 MOPD multi-teacher · prompt-routed · on-policy。## Slide 11: Baseline 机制与失败形态

### 页面内容覆盖
- Related Work / Baselines Baseline 机制与论文指出的失败形态 Table 1 与 §4.2 的桥接页 Mix-RL 把多域 prompt 池化到同一 RL batch；每条样本仍用自己的 domain reward / 优势函数（advantage）。
- 问题：跨域信号干扰，出现 see-saw effect，整体落后 teacher。
- Cascade RL 按领域顺序训练，论文默认 IF→Math→SWE。
- 问题：后续领域会损伤前序能力，长链路放大稳定性风险。
- Off-Policy FT 先训练 domain teacher，再用 teacher 采样轨迹（teacher rollouts）对 student 做离线 SFT。
- 问题：teacher trajectory 与 student inference trajectory 不一致，产生 exposure bias。
- Param-Merge 平均 teacher weights 或做 task arithmetic。
- 问题：weight-space 参数冲突，recipe/系数敏感。

### 扩写讲稿
相关工作中的机制差异会在后面的 baseline 结果里体现。
论文把每类 baseline 的训练机制和失败机制对应起来：Mix-RL 的干扰、Cascade 的遗忘或退化、Off-Policy 的 exposure bias、Param-Merge 的权重空间（weight space）冲突。
后面 Table 2 的结果基本就是这些失败机制的实证表现。
这里要把公式翻译成训练动作：teacher-student log gap 决定方向，student 的 log-prob 决定可更新对象，停止梯度（stop-gradient）和 clipping 控制这个训练信号的稳定性。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：Related Work / Baselines Baseline 机制与论文指出的失败形态 Table 1 与 §4.2 的桥接页 Mix-RL 把多域 prompt 池化到同一 RL batch；每条样本仍用自己的 domain reward / 优势函数（advantage）。；问题：跨域信号干扰，出现 see-saw effect，整体落后 teacher。；Cascade RL 按领域顺序训练，论文默认 IF→Math→SWE。；问题：后续领域会损伤前序能力，长链路放大稳定性风险。；Off-Policy FT 先训练 domain teacher，再用 teacher 采样轨迹（teacher rollouts）对 student 做离线 SFT。；问题：teacher trajectory 与 student inference trajectory 不一致，产生 exposure bias。。## Slide 12: 澄清：MOPD 也混多域数据，为什么干扰更弱？

### 页面内容覆盖
- Related Work clarification 澄清：MOPD 也混多域数据，为什么干扰更弱？ 关键差别在于混合的信号类型 Mix-RL 同一个 RL run 里混合 Math / IF / SWE 的 reward、优势函数（advantage）、采样轨迹（rollout）过程。
- reward scale 不同 优势函数（advantage）方差不同 采样轨迹（rollout）长度与环境不同 MOPD Stage 2 先独立完成单域 RL；Stage 3 混合 frozen teachers 的 token-level policy signal。
- prompt 按 domain 路由 teacher log-prob / top-k logits 统一 reverse-KL 蒸馏目标 信号来源对比：Mix-RL 混在一起的是不同 reward 产生的更新压力；MOPD 混在一起的是冻结教师给出的 token 概率信号。

### 扩写讲稿
常见疑问：MOPD 也用了多领域 prompt，为什么跨域干扰更弱。
核心区别在信号层级。
Mix-RL 在一个训练 run 里直接混合不同领域的 reward 尺度、优势函数（advantage）方差、采样轨迹（rollout）长度和环境反馈。
MOPD 在 Stage 2 先让每个领域独立完成高方差 RL，Stage 3 再混合 frozen teachers 给出的 token-level log-prob 或 top-k logits。
最终 student 仍共享参数，所以跨域 trade-off 仍可能存在；MOPD 的优势是把干扰从原始 RL recipe 层转移到统一蒸馏目标层。
这里要把公式翻译成训练动作：teacher-student log gap 决定方向，student 的 log-prob 决定可更新对象，停止梯度（stop-gradient）和 clipping 控制这个训练信号的稳定性。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
展开页面内容时，可以按这个顺序讲：Related Work clarification 澄清：MOPD 也混多域数据，为什么干扰更弱？ 关键差别在于混合的信号类型 Mix-RL 同一个 RL run 里混合 Math / IF / SWE 的 reward、优势函数（advantage）、采样轨迹（rollout）过程。；reward scale 不同 优势函数（advantage）方差不同 采样轨迹（rollout）长度与环境不同 MOPD Stage 2 先独立完成单域 RL；Stage 3 混合 frozen teachers 的 token-level policy signal。；prompt 按 domain 路由 teacher log-prob / top-k logits 统一 reverse-KL 蒸馏目标 信号来源对比：Mix-RL 混在一起的是不同 reward 产生的更新压力；MOPD 混在一起的是冻结教师给出的 token 概率信号。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 3: 3. 方法

### 页面内容覆盖
- 方法细节逐步拆解 3. 方法 接下来按论文顺序展开这一部分。

### 扩写讲稿
进入方法部分，这是本报告主体。

展开页面内容时，可以按这个顺序讲：方法细节逐步拆解 3. 方法 接下来按论文顺序展开这一部分。。## Slide 14: Pipeline 总览：三阶段

### 页面内容覆盖
- 方法 §3.1 论文 Figure 1：MOPD 三阶段总览 用原图先建立全局坐标，再进入后面的局部拆解。
- 原图读法：左侧 SFT 给共同起点；中间各领域独立训练 teacher；右侧 Stage 3 中 student 生成、teacher prefill 打分、reverse KL 更新。
- 读图提示：同源起点、并行生产、在线集成。

### 扩写讲稿
Figure 1 给出 MOPD 的三阶段主流程。
讲图时按照从左到右的顺序。
Stage 1 是 general SFT，得到共享 SFT checkpoint。这个 checkpoint 非常关键，因为后面的 domain teachers 和 MOPD student 都从这里初始化。
Stage 2 是 domain-specialized training。Math、Instruction Following、Software Engineering、Search、Safety 等领域各自训练自己的 domain expert。
Stage 3 是 MOPD。student model 先生成 token 序列；teacher models 只做 prefill，沿着 student 已经生成的同一条轨迹计算 token-level 信号；optimizer 再用 reverse KL 更新 student。
这张图最适合强调两点：第一，同源起点保证 teacher 和 student 初始分布接近；第二，teacher 不是重新生成答案，而是在 student 自己的轨迹上评分。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：方法 §3.1 论文 Figure 1：MOPD 三阶段总览；左侧 SFT 共同起点；中间各领域独立 teacher；右侧 student 生成、teacher prefill、reverse KL 更新；下方三个读图提示：同源起点、并行生产、在线集成。## Slide 15: 全局架构：能力生产与能力融合解耦

### 页面内容覆盖
- 方法架构 全局架构：能力生产与能力融合解耦 点击图中模块，可突出对应子系统 ① 共享 SFT 共同初始化 同一个 checkpoint 同时派生 teachers 和 student → ② 数学教师 可验证答案 RL ② 指令教师 规则评审 RL ② 软件工程教师 沙箱 RL → ③ 学生模型 πθ 生成 y ~ πθ ③ 领域路由器 domain(x)
- → 教师 d ③ 反向 KL（Reverse KL）同前缀更新 SFT checkpoint 同时初始化 teacher 和 student，保证 same-origin。Loss 比较同一前缀 (x, y1:t-1)
- 下的 πθ 与 πϕᵈ。

### 扩写讲稿
全局架构把能力生产和能力融合拆开。
讲解时可以点击模块：Shared SFT 解释 same-origin，teacher 模块解释能力生产并行，router 解释 prompt-routed teacher dispatch，loss 模块解释 token-level reverse KL 如何把能力融合回 student。
讲这类页面时要一直抓住一个问题：训练信号到底落在谁已经访问到的状态上。Reverse KL 的权重来自 student，所以它优先处理 student 当前会走到、会采样、会暴露出来的 token 决策。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：方法架构 全局架构：能力生产与能力融合解耦 点击图中模块，可突出对应子系统 ① 共享 SFT 共同初始化 同一个 checkpoint 同时派生 teachers 和 student → ② 数学教师 可验证答案 RL ② 指令教师 规则评审 RL ② 软件工程教师 沙箱 RL → ③ 学生模型 πθ 生成 y ~ πθ ③ 领域路由器 domain(x)；→ 教师 d ③ 反向 KL（Reverse KL）同前缀更新 SFT checkpoint 同时初始化 teacher 和 student，保证 same-origin。Loss 比较同一前缀 (x, y1:t-1)；下的 πθ 与 πϕᵈ。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 4: 阶段 1：共享 SFT checkpoint

### 页面内容覆盖
- 方法 §3.1 阶段 1：共享 SFT checkpoint 两个用途 初始化阶段 2 的每个领域教师 初始化阶段 3 的 MOPD 学生模型 隐藏假设 teacher 与 student 同源，初始 policy distribution 接近，reverse KL 不会一开始就处在高发散区域。
- 这里的 SFT 起什么作用 它在当前内容充当共同起跑线：先让 base model 学会按指令答题，再从同一个 checkpoint 分出教师和学生。
- \(-\sum_t \log p(y_t^\star)\)

### 扩写讲稿
Stage 1 在这篇论文里承担稳定性基础的角色。
作者明确说，SFT checkpoint 一方面作为 Stage-2 各 domain teacher 的初始化，另一方面也作为 Stage-3 student 的初始化。
这意味着 teacher 和 student 从同一个 policy family 演化出来。
这样做的好处是初始 KL 比较低，student 采样轨迹（rollout）访问到的状态通常也不会离 teacher 太远。
后面消融会显示，更强且不同源的外部 teacher 会造成训练不稳定甚至崩溃。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：方法 §3.1 阶段 1：共享 SFT checkpoint 两个用途 初始化阶段 2 的每个领域教师 初始化阶段 3 的 MOPD 学生模型 隐藏假设 teacher 与 student 同源，初始 policy distribution 接近，reverse KL 不会一开始就处在高发散区域。；这里的 SFT 起什么作用 它在当前内容充当共同起跑线：先让 base model 学会按指令答题，再从同一个 checkpoint 分出教师和学生。；\(-\sum_t \log p(y_t^\star)\)。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。
补充说明：这里的 SFT 起什么作用： 它在当前内容充当共同起跑线：先让 base model 学会按指令答题，再从同一个 checkpoint 分出教师和学生。 公式：\(-\sum_t \log p(y_t^\star)\)

## Slide 5: 阶段 2：领域强化学习教师并行生产

### 页面内容覆盖
- 方法 §3.1 阶段 2：领域强化学习教师并行生产 数学 可验证答案强化学习；答对给正反馈 \(\pi_\phi^{\mathrm{math}}\)
- 指令跟随 基于规则或评审标准打分 \(\pi_\phi^{\mathrm{if}}\)
- 软件工程 在可执行沙箱里验证补丁或代理行为 \(\pi_\phi^{\mathrm{swe}}\)
- 其他领域 搜索、安全、创作等独立训练流程 \(\pi_\phi^{d}\)
- 看横向三条训练线：每个领域自己选奖励、采样、训练轮数和超参，失败也只影响本领域教师。

### 扩写讲稿
Stage 2 的重点是“能力生产解耦”。
每个领域 teacher 都可以用最适合自己任务的 RL 方案：数学可以用可验证答案 reward，SWE 可以用 sandbox 里的执行反馈，IF 可以用 benchmark 或 rubric 构造 reward。
这和 Mix-RL 或 Cascade RL 很不一样。
Mix-RL 把多个领域塞到同一次训练里，梯度和 reward 分布会互相干扰。
Cascade RL 按顺序训练，后训练的领域可能损伤前面的领域。
MOPD 则把 teacher 训练全部并行化：哪个领域需要调 reward 或超参，只影响这个领域的 teacher，不影响其他领域。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
展开页面内容时，可以按这个顺序讲：方法 §3.1 阶段 2：领域强化学习教师并行生产 数学 可验证答案强化学习；答对给正反馈 \(\pi_\phi^{\mathrm{math}}\)；指令跟随 基于规则或评审标准打分 \(\pi_\phi^{\mathrm{if}}\)；软件工程 在可执行沙箱里验证补丁或代理行为 \(\pi_\phi^{\mathrm{swe}}\)；其他领域 搜索、安全、创作等独立训练流程 \(\pi_\phi^{d}\)；看横向三条训练线：每个领域自己选奖励、采样、训练轮数和超参，失败也只影响本领域教师。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 6: 阶段 3：一次 MOPD 更新做什么？

### 页面内容覆盖
- 方法 §3.1 阶段 3：一次 MOPD 更新做什么？ 这一步把多个领域教师的能力写回同一个学生模型 1 取一个领域问题 从混合数据集中取 prompt x，同时知道它属于哪个领域 d。这个 d 决定后面请哪位教师来评分。
- → 2 让学生先作答 当前学生模型 πθ 自己生成完整回答 y。训练用的是学生实际会写出的轨迹。
- → 3 请对应教师打分 把同一条回答 y 送给领域教师 πϕᵈ。教师逐 token 计算：学生这个 token 在教师眼里有多合理。
- → 4 用分数更新学生 优化器把教师概率信号写进 loss，用逐 token reverse KL 提高学生对教师认可 token 的概率。
- 核心顺序：学生先写答案，教师再评分，优化器最后更新学生。教师不替学生改写答案，只告诉训练器“在这个前缀下，学生选出的 token 和教师分布有多接近”。
- 这里的 y 是什么 y 指学生当前模型刚采样出的完整回答。后面的教师评分、KL 计算和梯度更新都沿着这条回答展开，所以这一步是在线策略（on-policy）训练。
- \(y=(y_1,\dots,y_T)\sim\pi_\theta(\cdot\mid x)\)

### 扩写讲稿
Stage 3 是论文的方法执行循环。
一步 MOPD 可以拆成四个动作：第一，从 multi-domain dataset 采样 prompt，并知道它属于哪个 domain；第二，student πθ 根据这个 prompt 自己生成采样轨迹（rollout） y；第三，把这条 y 按 domain dispatch 给对应 teacher πϕᵈ，teacher 只做 prefill，计算每个 token 在相同前缀下的 log-probability；第四，用这些 teacher 信号最小化 per-token reverse KL。
这里最容易误解的是 teacher 的角色。
teacher 是 scorer，负责在 student 轨迹上计算概率信号，它在 student 已经走到的状态上评价 student 的 token 分布。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
展开页面内容时，可以按这个顺序讲：方法 §3.1 阶段 3：一次 MOPD 更新做什么？ 这一步把多个领域教师的能力写回同一个学生模型 1 取一个领域问题 从混合数据集中取 prompt x，同时知道它属于哪个领域 d。这个 d 决定后面请哪位教师来评分。；→ 2 让学生先作答 当前学生模型 πθ 自己生成完整回答 y。训练用的是学生实际会写出的轨迹。；→ 3 请对应教师打分 把同一条回答 y 送给领域教师 πϕᵈ。教师逐 token 计算：学生这个 token 在教师眼里有多合理。；→ 4 用分数更新学生 优化器把教师概率信号写进 loss，用逐 token reverse KL 提高学生对教师认可 token 的概率。；核心顺序：学生先写答案，教师再评分，优化器最后更新学生。教师不替学生改写答案，只告诉训练器“在这个前缀下，学生选出的 token 和教师分布有多接近”。；这里的 y 是什么 y 指学生当前模型刚采样出的完整回答。后面的教师评分、KL 计算和梯度更新都沿着这条回答展开，所以这一步是在线策略（on-policy）训练。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。
补充说明：这里的 y 是什么： y 指学生当前模型刚采样出的完整回答。后面的教师评分、KL 计算和梯度更新都沿着这条回答展开，所以这一步是在线策略（on-policy）训练。 公式：\(y=(y_1,\dots,y_T)\sim\pi_\theta(\cdot\mid x)\)

## Slide 7: 阶段 3 时序图：单条轨迹的评分流程

### 页面内容覆盖
- 方法时序图 阶段 3 时序图：单条轨迹的评分流程 教师不解码，只做预填充（prefill）评分 数据集 学生采样器 教师服务 优化器 采样问题 x 与领域 d 生成轨迹 y ~ πθ 把整条学生答案送给教师评分 返回每个位置的教师概率信号 最小化反向 KL（Reverse KL）这条箭头的含义：学生已经写完答案 y，教师沿着同一条答案逐位打分。
- 第 t 位只问一个问题：在前缀 x, y 1:t-1 已经固定时，领域教师会给学生选出的 y t 多大概率？公式就是 \(\log \pi_{\phi^d}(y_t\mid x,y_{1:t-1})\)。Top-k 版本再补充教师在同一前缀下最看好的 k 个候选 token。

### 扩写讲稿
Stage 3 的控制流可以按四个动作理解。
Dataset 只提供 prompt 与 domain；Student Sampler 负责生成轨迹；Teacher Service 只做 prefill scorer；Optimizer 才根据 reverse KL 更新 student。
讲这类页面时要一直抓住一个问题：训练信号到底落在谁已经访问到的状态上。Reverse KL 的权重来自 student，所以它优先处理 student 当前会走到、会采样、会暴露出来的 token 决策。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
展开页面内容时，可以按这个顺序讲：方法时序图 阶段 3 时序图：单条轨迹的评分流程 教师不解码，只做预填充（prefill）评分 数据集 学生采样器 教师服务 优化器 采样问题 x 与领域 d 生成轨迹 y ~ πθ 把整条学生答案送给教师评分 返回每个位置的教师概率信号 最小化反向 KL（Reverse KL）这条箭头的含义：学生已经写完答案 y，教师沿着同一条答案逐位打分。；第 t 位只问一个问题：在前缀 x, y 1:t-1 已经固定时，领域教师会给学生选出的 y t 多大概率？公式就是 \(\log \pi_{\phi^d}(y_t\mid x,y_{1:t-1})\)。Top-k 版本再补充教师在同一前缀下最看好的 k 个候选 token。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 8: 为什么 Stage 3 要让学生先生成？

### 页面内容覆盖
- 方法直觉 为什么 Stage 3 要让学生先生成？ Stage 3 的结论：训练样本来自 student 当前策略 离线微调的路径 训练时看教师写过的答案前缀；部署时学生沿着自己的历史 token 继续写。
- 教师前缀 → 训练 学生前缀 → 推理 放大：前缀错位 MOPD 的路径 训练样本来自学生当前回答；教师沿着这条回答逐 token 评分。
- 学生先生成 → 教师再评分 → 更新学生 对应：学生生成 → 教师评分 → 更新学生 接下来为什么拆前缀 训练轨迹来源决定是否发生前缀错位。离线微调的问题集中在同一个位置 t 的训练条件和推理条件分叉。
- \(\text{on-policy: }y\sim\pi_\theta,\quad \text{off-policy: }y\sim\pi_\phi\)

### 扩写讲稿
Stage 3 的关键结论是：训练样本必须来自 student 当前策略。
关键是训练轨迹来源：离线微调用 teacher 或固定数据里的轨迹训练 student；MOPD 用 student 当前自己生成的轨迹训练 student。
左边对应后续要展开的失败路径：训练时 student 站在 teacher 前缀后面，部署时 student 站在自己的前缀后面。
右边对应 MOPD 的修正路径：student 先生成，teacher 再沿这条生成结果逐 token 打分。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
展开页面内容时，可以按这个顺序讲：方法直觉 为什么 Stage 3 要让学生先生成？ Stage 3 的结论：训练样本来自 student 当前策略 离线微调的路径 训练时看教师写过的答案前缀；部署时学生沿着自己的历史 token 继续写。；教师前缀 → 训练 学生前缀 → 推理 放大：前缀错位 MOPD 的路径 训练样本来自学生当前回答；教师沿着这条回答逐 token 评分。；学生先生成 → 教师再评分 → 更新学生 对应：学生生成 → 教师评分 → 更新学生 接下来为什么拆前缀 训练轨迹来源决定是否发生前缀错位。离线微调的问题集中在同一个位置 t 的训练条件和推理条件分叉。；\(\text{on-policy: }y\sim\pi_\theta,\quad \text{off-policy: }y\sim\pi_\phi\)。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。
补充说明：前缀错位的原因： 训练轨迹来源决定是否发生前缀错位。离线微调的问题集中在同一个位置 t 的训练条件和推理条件分叉。 公式：\(\text{on-policy: }y\sim\pi_\theta,\quad \text{off-policy: }y\sim\pi_\phi\)

## Slide 9: 离线微调哪里错位？

### 页面内容覆盖
- 方法详解 离线微调哪里错位？ 同一个位置 t，训练和推理条件在不同前缀上 1. 离线路径：离线微调训练时 第 t 位预测条件在教师答案前缀上：x, y 1:t-1 teacher。学生学习的是“站在教师写法后面该怎么接”。
- 2. 部署时：学生只能接自己的历史 同样是第 t 位，推理条件变成学生前缀：x, y 1:t-1 student。早期一个 token 偏掉，后面的状态就跟训练时不同。
- 3. 暴露偏差（exposure bias）指的就是这个前缀分叉 训练覆盖的是教师路径附近的状态；推理会走到学生自己产生的状态。越长的回答，前缀分叉越容易累积。
- 4. 回到 MOPD：让教师在学生路径上打分 学生先生成 y ~ πθ，教师再沿着这条 y 计算 log-prob。训练信号直接落在学生实际访问到的前缀上。
- 承接关系 两种训练路径的差异最终落在前缀分布上。核心变量是前缀分布：训练前缀来自教师，推理前缀来自学生。
- \(p_{\mathrm{train}}(y_{1:t-1})\ne p_{\mathrm{infer}}(y_{1:t-1})\)

### 扩写讲稿
离线微调的失败路径来自 teacher 前缀和 student 前缀不一致。
训练时 student 条件在 teacher 前缀上，推理时 student 条件在自己的历史 token 上。
MOPD 回到前文右侧路径：student 先生成轨迹，teacher 在这条轨迹上评分，因此每个前缀状态都来自 student 实际访问到的区域。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
展开页面内容时，可以按这个顺序讲：方法详解 离线微调哪里错位？ 同一个位置 t，训练和推理条件在不同前缀上 1. 离线路径：离线微调训练时 第 t 位预测条件在教师答案前缀上：x, y 1:t-1 teacher。学生学习的是“站在教师写法后面该怎么接”。；2. 部署时：学生只能接自己的历史 同样是第 t 位，推理条件变成学生前缀：x, y 1:t-1 student。早期一个 token 偏掉，后面的状态就跟训练时不同。；3. 暴露偏差（exposure bias）指的就是这个前缀分叉 训练覆盖的是教师路径附近的状态；推理会走到学生自己产生的状态。越长的回答，前缀分叉越容易累积。；4. 回到 MOPD：让教师在学生路径上打分 学生先生成 y ~ πθ，教师再沿着这条 y 计算 log-prob。训练信号直接落在学生实际访问到的前缀上。；承接关系 两种训练路径的差异最终落在前缀分布上。核心变量是前缀分布：训练前缀来自教师，推理前缀来自学生。；\(p_{\mathrm{train}}(y_{1:t-1})\ne p_{\mathrm{infer}}(y_{1:t-1})\)。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。
补充说明：承接关系： 两种训练路径的差异最终落在前缀分布上。核心变量是前缀分布：训练前缀来自教师，推理前缀来自学生。 公式：\(p_{\mathrm{train}}(y_{1:t-1})\ne p_{\mathrm{infer}}(y_{1:t-1})\)

## Slide 10: 澄清：离线策略（off-policy）与在线策略（on-policy）的边界

### 页面内容覆盖
- 方法澄清 澄清：离线策略（off-policy）与在线策略（on-policy）的边界 在线策略（on-policy）缓解状态错位，无法覆盖所有未来分布 适用范围 离线数据仍有价值 高质量人工数据、短输出任务、格式学习和初始 SFT 都常用离线数据。
- 原因 MOPD 选择在线策略（on-policy）长链生成和多教师集成中，学生自己的前缀更值得被教师纠偏。
- 边界 残留风险 策略更新、解码策略变化、测试问题变化都会带来新分布。
- 结论边界：MOPD 让教师在学生当前轨迹上评分；更新稳定性还依赖后续这些训练护栏。

### 扩写讲稿
这里澄清两个常见问题。
off-policy 学习本身很有用，SFT 就是典型例子。
MOPD 针对的是多步生成和能力集成（capability integration）中的 teacher/student trajectory 错位。
on-policy 训练也存在 policy update 后的数据陈旧、测试分布变化和长链误差滚动；论文的做法是用 学生自身采样轨迹（student own rollouts）、停止梯度优势函数（stop-gradient advantage）、优势函数裁剪（advantage clipping）和 same-origin teacher 控制训练稳定性。
这里要把公式翻译成训练动作：teacher-student log gap 决定方向，student 的 log-prob 决定可更新对象，停止梯度（stop-gradient）和 clipping 控制这个训练信号的稳定性。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：方法澄清 澄清：离线策略（off-policy）与在线策略（on-policy）的边界 在线策略（on-policy）缓解状态错位，无法覆盖所有未来分布 适用范围 离线数据仍有价值 高质量人工数据、短输出任务、格式学习和初始 SFT 都常用离线数据。；原因 MOPD 选择在线策略（on-policy）长链生成和多教师集成中，学生自己的前缀更值得被教师纠偏。；边界 残留风险 策略更新、解码策略变化、测试问题变化都会带来新分布。；结论边界：MOPD 让教师在学生当前轨迹上评分；更新稳定性还依赖后续这些训练护栏。。## Slide 23: MOPD 的稳定性护栏如何起作用？

### 页面内容覆盖
- 方法细节补充 MOPD 的稳定性护栏如何起作用？听众只需要理解：每个护栏分别在控制哪一种不稳定来源。
- 学生自己的采样轨迹（rollout）：教师不是在自己写出的答案上教学，而是在学生已经走到的前缀上评分。这样训练覆盖的是学生真实会犯错、会分叉的位置，减少 teacher-forcing 式状态错位。
- 停止梯度优势函数（stop-gradient advantage）：教师-学生 log gap 只作为“这个 token 该推高还是压低”的固定权重；反传只更新 student 的 log-prob，不让这个权重本身继续被优化器追着改。
- 双边裁剪（two-side clipping）：如果某个 token 的 teacher-student gap 过大，直接更新会造成单步梯度过猛。裁剪把正负方向都限制在安全范围内，让训练更像连续纠偏，而不是一次性大幅改写分布。
- 同源教师（same-origin teacher）：teacher 和 student 从同一个 SFT checkpoint 出发，初始语言习惯和概率分布相近。教师在学生轨迹上给分时，更容易给出平滑可用的 token 信号，而不是大量极端负反馈。
- 反复采样学生答案：每轮更新后 student 会变，下一批回答也会变。MOPD 反复用当前 student 生成新轨迹，再让 teacher 评分，因此监督会跟着 student 当前错误分布移动。
- 这里的结论：MOPD 的稳定性不是靠单个 trick，而是靠“学生轨迹 + 固定权重 + 幅度裁剪 + 同源教师”共同把更新限制在学生当前可理解的区域内。

### 扩写讲稿
稳定性机制可以直接理解为四个训练护栏。
第一个护栏是学生自己的采样轨迹。教师不重新生成答案，只在学生已经写出的前缀上评分。这样训练信号覆盖的是学生实际会进入的状态，而不是教师路径附近的理想状态，所以能减少 teacher-forcing 带来的状态错位。
第二个护栏是停止梯度优势函数。这里的 advantage 来自 \(\log\pi_{\phi^d}(y_t)-\log\pi_\theta(y_t)\)，它只告诉优化器当前 token 应该被推高还是压低。加上 stop-gradient 后，这个差值被当成固定权重，反传主要作用在 student 的 \(\log\pi_\theta(y_t)\) 上，不让权重自身继续产生复杂的二阶反馈。
第三个护栏是双边裁剪。如果 teacher 和 student 在某个 token 上差距特别大，不裁剪会让这一个 token 产生过强更新。双边裁剪把正向和负向更新都限制住，让训练更像逐步纠偏，而不是被少数极端 token 拉着走。
第四个护栏是同源教师。teacher 和 student 来自同一个 SFT checkpoint，初始语言分布接近。这样 teacher 在 student 轨迹上评分时，大多数前缀仍在 teacher 能理解和稳定评估的区域里，极端低概率区域更少。
第五个护栏是反复采样学生答案。student 每更新一段时间，生成分布就会变化；继续用当前 student 生成新回答，再让 teacher 评分，可以让监督跟着当前错误分布移动。
论文依据保留在讲者 notes 里即可：§3.1 对 student rollout 进行描述；Eq. (3) 写出 stop-gradient advantage；§3.2.1 写明 clip 到 \([-A_{\max}, A_{\max}]\)；§4.4.2 对比 same-origin teacher 与外部 teacher 的初始 KL；Appendix 说明 MOPD 不使用 Dynamic Sampling。
这里要把公式翻译成训练动作：teacher-student log gap 决定方向，student 的 log-prob 决定可更新对象，停止梯度（stop-gradient）和 clipping 控制这个训练信号的稳定性。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：先看“学生轨迹”控制状态分布，再看“停止梯度”固定权重，再看“裁剪”限制步长，再看“同源教师”降低分布错位，最后看“反复采样”让监督跟随当前 student。讲解目标是让听众理解每个护栏控制的是哪一种不稳定来源。
遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 11: 优化目标：per-token reverse KL

### 页面内容覆盖
- 方法 §3.2 优化目标：逐 token 反向 KL（per-token Reverse KL） \[\mathcal{L}_{\mathrm{rev\text{-}KL}}=\mathbb{E}_{x,\,y\sim\pi_\theta}\left[\frac{1}{|y|}\sum_t\sum_v \pi_\theta(v)\log\frac{\pi_\theta(v)}{\pi_{\phi^d}(v)}\right]\]
- 其中 \(\pi_\theta(v)=\pi_\theta(v\mid x,y_{1:t-1})\)，\(\pi_{\phi^d}(v)=\pi_{\phi^d}(v\mid x,y_{1:t-1})\)，\(d=\mathrm{domain}(x)\)。这里 \(y_t\) 是 student 实际采样 token，\(v\) 是该位置的候选词表 token。
- x 问题，带有领域信息 y ~ πθ 学生模型自己生成的轨迹 πϕᵈ 由领域 d 路由到的冻结教师 逐 token 每个前缀位置上比较分布 KL 惩罚对象 在同一个前缀下，如果学生把高概率给了教师不认可的 token，这一项就变大。优化会把学生分布往领域教师靠近。
- \(P(v)\uparrow,\ Q(v)\downarrow\Rightarrow \mathrm{KL}\uparrow\)

### 扩写讲稿
目标函数是 Stage 3 的数学表达。
外层期望 x, y~πθ 表示：prompt 来自数据集，而 completion y 来自 student 当前策略，所以这是 on-policy。
中间的 1/|y| Σ_t 表示对 采样轨迹（rollout）中每个 token 位置平均，因此监督非常 dense。
内层 Σ_v πθ(v) log(πθ(v)/πϕᵈ(v)) 是每个位置上的 reverse KL。
这里 \(\pi_\theta(v)\) 和 \(\pi_{\phi^d}(v)\) 都是 shorthand，完整条件是 \(v\mid x,y_{1:t-1}\)。
\(\pi_{\phi^d}\) 里的 \(d\) 是 prompt 的领域路由结果：数学 prompt 路由给数学 teacher，SWE prompt 路由给 SWE teacher。
讲这类页面时要一直抓住一个问题：训练信号到底落在谁已经访问到的状态上。Reverse KL 的权重来自 student，所以它优先处理 student 当前会走到、会采样、会暴露出来的 token 决策。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
展开页面内容时，可以按这个顺序讲：方法 §3.2 优化目标：逐 token 反向 KL（per-token Reverse KL） \[\mathcal{L}_{\mathrm{rev\text{-}KL}}=\mathbb{E}_{x,\,y\sim\pi_\theta}\left[\frac{1}{|y|}\sum_t\sum_v \pi_\theta(v)\log\frac{\pi_\theta(v)}{\pi_{\phi^d}(v)}\right]\]；其中 πθ(v)=πθ(v | x,y 1:t-1 )，πϕᵈ(v)=πϕᵈ(v | x,y 1:t-1 )，d=domain(x)。这里 y t 是 student 实际采样 token，v 是该位置的候选词表 token。；x 问题，带有领域信息 y ~ πθ 学生模型自己生成的轨迹 πϕᵈ 由领域 d 路由到的冻结教师 逐 token 每个前缀位置上比较分布 KL 惩罚对象 在同一个前缀下，如果学生把高概率给了教师不认可的 token，这一项就变大。优化会把学生分布往领域教师靠近。；\(P(v)\uparrow,\ Q(v)\downarrow\Rightarrow \mathrm{KL}\uparrow\)。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。
补充说明：KL 惩罚对象： 在同一个前缀下，如果学生把高概率给了教师不认可的 token，这一项就变大。优化会把学生分布往领域教师靠近。 公式：\(P(v)\uparrow,\ Q(v)\downarrow\Rightarrow \mathrm{KL}\uparrow\)

## Slide 12: 详解：目标函数逐项拆开

### 页面内容覆盖
- 方法详解 详解：目标函数逐项拆开 先看采样，再看 token，再看分布 \[\mathbb{E}_{x,\,y\sim\pi_\theta}\left[\frac{1}{|y|}\sum_t\sum_v \pi_\theta(v)\log\frac{\pi_\theta(v)}{\pi_{\phi^d}(v)}\right]\]
- \(\mathbb{E}_{x,y\sim\pi_\theta}\)
- 问题来自数据集，回答来自学生当前策略。
- \(\sum_t\)
- 沿 采样轨迹（rollout）的每个 token 位置都给监督，覆盖整条生成过程。
- \(\sum_v\)
- 比较整个词表分布；Top-k 版本只传 teacher top-k 近似。
- \(\log \pi_\theta/\pi_{\phi^d}\)
- 学生比教师更偏好的 token 会产生惩罚。

### 扩写讲稿
公式按外层期望、位置求和、词表求和三层展开。
强调三层求和/期望：外层是 student 采样轨迹（rollout）分布，中间是 token 位置，内层是词表 token 分布。
这样听众能理解为什么它是 on-policy 且 dense。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
展开页面内容时，可以按这个顺序讲：方法详解 详解：目标函数逐项拆开 先看采样，再看 token，再看分布 \[\mathbb{E}_{x,\,y\sim\pi_\theta}\left[\frac{1}{|y|}\sum_t\sum_v \pi_\theta(v)\log\frac{\pi_\theta(v)}{\pi_{\phi^d}(v)}\right]\]；\(\mathbb{E}_{x,y\sim\pi_\theta}\)；问题来自数据集，回答来自学生当前策略。；\(\sum_t\)；沿 采样轨迹（rollout）的每个 token 位置都给监督，覆盖整条生成过程。；\(\sum_v\)。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 13: 详解：Reverse KL 与 Forward KL 的差别

### 页面内容覆盖
- 方法详解 拖动滑条理解 Reverse KL：看 student 把概率放在哪些 token 上，KL 惩罚会怎样变。
- 固定前缀：“因此我们可以得到 …”。teacher 分布固定为：“因此”0.45，“所以”0.40，“跑题词”0.01，“其他”0.14。
- 滑条表示 student 当前分布；滑条下方的粗柱表示固定 teacher 分布，用来参照 student 是否偏离教师。
- Reverse KL 公式：\(\mathrm{KL}_{\mathrm{rev}}(P\Vert Q)=\sum_v P(v)\log\frac{P(v)}{Q(v)}\)。
- Forward KL 公式：\(\mathrm{KL}_{\mathrm{fwd}}(Q\Vert P)=\sum_v Q(v)\log\frac{Q(v)}{P(v)}\)。
- 实际作用：滑条表示 student 当前分布；滑条下方的粗柱是固定 teacher 分布；下方的小条只辅助提示 KL 对该方向的敏感度。

### 扩写讲稿
这里的交互规则要讲清楚：前三个滑条是自由变量，分别控制 therefore、so 和跑题词的 student 概率；“其他”不是独立滑条，而是自动等于 1 减去前三项。滑条下方的粗柱固定表示 teacher 分布，不再重复画 student 分布；这样听众可以直接对照 student 当前滑条位置和 teacher 参考概率之间的距离。下方小条只作为辅助，提示 KL 对该方向的敏感度。 讲解时先把两个公式重新放出来：\(\mathrm{KL}_{\mathrm{rev}}(P\Vert Q)=\sum_v P(v)\log\frac{P(v)}{Q(v)}\)，\(\mathrm{KL}_{\mathrm{fwd}}(Q\Vert P)=\sum_v Q(v)\log\frac{Q(v)}{P(v)}\)。这里 \(P\) 是 student，\(Q\) 是 teacher。Forward KL 的权重来自 teacher，它更强调覆盖 teacher 认为合理的 token；Reverse KL 的权重来自 student，它更强调纠正 student 当前真的会选的 token。 MOPD 使用 student 采样轨迹（rollout），因此 reverse KL 更贴合它的训练数据来源。 这里先提供可拖动直觉，后续再用固定数值例子解释 Forward KL 和 Reverse KL 在更新分布上的倾向差异。
遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 14: 数值例子：Forward KL 和 Reverse KL 的更新倾向

### 页面内容覆盖
- KL 直觉补充 数值例子：两种 KL 想把分布往哪儿推？固定教师分布 \(Q\)，只看学生分布 \(P\) 的几种偏差。
- 教师分布 \(Q\)：答案可以有两个合理开头。“因此”0.45，“所以”0.40，“跑题词”0.01，“其他”0.14。
- Forward KL 看 \(Q\)：权重来自 teacher。teacher 认为重要的 token，如果 student 给得太低，会被强烈拉起来。
- Reverse KL 看 \(P\)：权重来自 student。student 自己放了大概率的 token，如果 teacher 不认可，会被强烈压下去。
- 例 1：\(P=[0.85,0.01,0.01,0.13]\)。Forward KL = 1.20，Reverse KL = 0.49。Forward KL 更急着补“所以”的覆盖。
- 例 2：\(P=[0.20,0.18,0.41,0.21]\)。Forward KL = 0.59，Reverse KL = 1.30。Reverse KL 更急着压低“跑题词”。
- 例 3：\(P=[0.43,0.39,0.03,0.15]\)。Forward KL = 0.01，Reverse KL = 0.01。两种 KL 都很小，更新变弱。
- 一句话：Forward KL 更像“补齐 teacher 覆盖的模式”；Reverse KL 更像“惩罚 student 自己高概率但 teacher 不认可的模式”。MOPD 在 student rollout 上训练，所以更关心后者。

### 扩写讲稿
这里专门补足前文滑条还不够直观的问题。
先固定 teacher 分布 \(Q=[0.45,0.40,0.01,0.14]\)。这个分布表示，“因此”和“所以”都是合理 token，“跑题词”几乎不合理，“其他”保留少量概率。
第一个 student 分布是 \(P=[0.85,0.01,0.01,0.13]\)。它的问题不是跑题，而是模式覆盖不足：student 几乎只会说“因此”，几乎不说 teacher 也认可的“所以”。这时 Forward KL 是 1.20，Reverse KL 是 0.49。Forward KL 更大，因为它按 teacher 权重看问题，teacher 在“所以”上有 0.40，所以会强烈要求 student 把“所以”补回来。Reverse KL 按 student 权重看问题，student 自己几乎不采样“所以”，所以漏掉“所以”的惩罚相对弱。
第二个 student 分布是 \(P=[0.20,0.18,0.41,0.21]\)。这里 student 把 0.41 的概率放到“跑题词”，但 teacher 对它只有 0.01。这时 Forward KL 是 0.59，Reverse KL 是 1.30。Reverse KL 更大，因为它最关注 student 自己已经放高概率的 token；一旦这个 token 在 teacher 看来非常不合理，惩罚会很强。
第三个 student 分布是 \(P=[0.43,0.39,0.03,0.15]\)。它已经接近 teacher，Forward KL 和 Reverse KL 都接近 0，更新主要是局部微调。
因此可以得到直觉：Forward KL 更偏向补覆盖，避免漏掉 teacher 的多种合理模式；Reverse KL 更偏向压掉 student 当前高概率但 teacher 不认可的模式。MOPD 使用 student rollout，训练信号来自 student 实际会生成的 token，所以它更需要后者，也就是在 student 当前错误偏好上做强纠偏。
收束时给后续铺垫：当前内容用数值例子说明两种 KL 的更新倾向，后续回到公式层级，解释 \(t\) 和 \(v\) 分别在累加什么。

## Slide 15: 公式里的累加关系：t 和 v 分别在加什么？

### 页面内容覆盖
- Method formula 公式里的累加关系：t 和 v 分别在加什么？ 这里不用额外例子，只看 loss 的层级 外层期望 先采样一批 prompt x，并让 student 生成回答 y。这里决定了训练数据来自 student 采样轨迹（rollout）。
- \(\sum_t\)：沿回答位置累加 回答有多少个 token，就在多少个前缀位置上计算一次 KL。第 t 位的前缀是 \(x,y_{1:t-1}\)。
- \(\sum_v\)：在同一位置的候选 token 上累加 固定第 t 位前缀后，student 和 teacher 都给整个词表一个分布；KL 在这些候选 token 上求和。
- 最终 loss 先得到每个位置的 KL，再对整条回答取平均：\(\frac1{|y|}\sum_t KL_t\)。
- 累加关系：\(t\)
- 是生成序列位置，\(v\)
- 是同一位置的候选 token。KL 直觉来自前面的滑条数值例子。

### 扩写讲稿
讲解时先重放拆成两行的大号 loss：
\[
\begin{aligned}
\mathcal{L}_{\mathrm{rev\text{-}KL}}
&=\mathbb{E}_{x,\,y\sim\pi_\theta}\left[
\frac{1}{|y|}\sum_t \mathrm{KL}_t
\right]\\
\mathrm{KL}_t
&=\sum_v \pi_\theta(v\mid x,y_{1:t-1})
\log\frac{\pi_\theta(v\mid x,y_{1:t-1})}
{\pi_{\phi^d}(v\mid x,y_{1:t-1})}
\end{aligned}
\]
第一行说明整条回答怎么聚合：对每个位置的 \(\mathrm{KL}_t\) 求平均，再对 student rollout 取期望。第二行说明某一个位置 \(t\) 的 KL 怎么算：固定前缀 \(x,y_{1:t-1}\)，在候选 token \(v\) 上比较 student 和 teacher 的分布。后面的每一行解释都回指这个公式里的对应片段，不要只讲文字标签。
公式层级只包含 prompt/rollout、token 位置和候选 token 三层。
外层是 prompt 和 student 采样轨迹（rollout）；中间的 t 是回答中的 token 位置；内层的 v 是某个位置上的候选 token。
先在每个位置算出一个 KL，再对整条回答取平均。

展开页面内容时，可以按这个顺序讲：Method formula 公式里的累加关系：t 和 v 分别在加什么？ 这里不用额外例子，只看 loss 的层级 外层期望 先采样一批 prompt x，并让 student 生成回答 y。这里决定了训练数据来自 student 采样轨迹（rollout）。；\(\sum_t\)：沿回答位置累加 回答有多少个 token，就在多少个前缀位置上计算一次 KL。第 t 位的前缀是 \(x,y_{1:t-1}\)。；\(\sum_v\)：在同一位置的候选 token 上累加 固定第 t 位前缀后，student 和 teacher 都给整个词表一个分布；KL 在这些候选 token 上求和。；最终 loss 先得到每个位置的 KL，再对整条回答取平均：\(\frac1{|y|}\sum_t KL_t\)。；累加关系：\(t\)；是生成序列位置，\(v\)。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 16: score-function trick 一：为什么能对采样求导？

### 页面内容覆盖
- 把期望展开：\(\nabla_\theta \mathbb{E}_{y\sim\pi_\theta}[f(y)]=\nabla_\theta \sum_y \pi_\theta(y)f(y)\)。
- 换成 log-prob 梯度：\(\nabla_\theta \pi_\theta(y)=\pi_\theta(y)\nabla_\theta\log\pi_\theta(y)\)。
- 这里的 \(f(y)\) 是采样结果 \(y\) 的评分函数；推导时先把它当成固定权重。

### 扩写讲稿
先解释 score-function trick 里 \(f(y)\) 到底是什么。\(y\) 是 student 当前策略采样出来的回答，\(f(y)\) 是这条回答拿到的评分权重。它可以来自 reward、return、advantage，也可以来自后面 MOPD 的 teacher-student log-prob gap。推导这一步时，先把 \(f(y)\) 当成固定分数，不让梯度穿过它。期望展开后，梯度作用在 \(\pi_\theta(y)\) 上；利用 \(\nabla p=p\nabla\log p\)，就能把采样分布的梯度改写成采样结果的 log-prob 梯度。这样采样到一个回答以后，就可以用 \(f(y)\) 给这条回答的 log-prob 更新加权。

## Slide 17: score-function trick：为什么 ∇p = p∇logp？

### 页面内容覆盖
- 从 log 的导数开始：\(\frac{\partial}{\partial\theta_i}\log p_\theta(y)=\frac{1}{p_\theta(y)}\frac{\partial p_\theta(y)}{\partial\theta_i}\)。
- 两边乘回 \(p_\theta(y)\)：\(\frac{\partial p_\theta(y)}{\partial\theta_i}=p_\theta(y)\frac{\partial}{\partial\theta_i}\log p_\theta(y)\)。
- 向量形式：\(\nabla_\theta p_\theta(y)=p_\theta(y)\nabla_\theta\log p_\theta(y)\)。

### 扩写讲稿
这里专门解释为什么 \(\nabla p=p\nabla\log p\)。先看一个参数坐标 \(\theta_i\)。因为 log 的导数是 \(1/p\)，所以 \(\log p_\theta(y)\) 对 \(\theta_i\) 求导时，会得到 \(\frac{1}{p_\theta(y)}\frac{\partial p_\theta(y)}{\partial\theta_i}\)。然后两边乘回 \(p_\theta(y)\)，就得到 \(\frac{\partial p_\theta(y)}{\partial\theta_i}=p_\theta(y)\frac{\partial}{\partial\theta_i}\log p_\theta(y)\)。这个等式对每一个参数坐标都成立，所以可以写成向量形式 \(\nabla_\theta p_\theta(y)=p_\theta(y)\nabla_\theta\log p_\theta(y)\)。这一步只是链式法则，没有引入新的目标。它的作用是把“概率本身的梯度”改写成“log-prob 的梯度”：前面的 \(p_\theta(y)\) 可以留在期望里当采样权重，后面的 \(\nabla_\theta\log p_\theta(y)\) 可以通过模型对采样结果的 log-prob 反向传播得到。

## Slide 18: score-function trick 二：落到 token 更新

### 页面内容覆盖
- 最终形式：\(\nabla_\theta \mathbb{E}_{y\sim\pi_\theta}[f(y)]=\mathbb{E}_{y\sim\pi_\theta}[f(y)\nabla_\theta\log\pi_\theta(y)]\)。
- 序列 log-prob 拆成 token：\(\log\pi_\theta(y)=\sum_t\log\pi_\theta(y_t\mid x,y_{1:t-1})\)。
- 在 MOPD 里，每个 token 的 \(f\) 不是环境 reward，而是 teacher logp - student logp，也就是 advantage。

### 扩写讲稿
最终形式是 \(f(y)\nabla_\theta\log\pi_\theta(y)\)。这句话的读法是：采样到了 \(y\)，就用 \(f(y)\) 这个评分去加权它的 log-prob 梯度。如果 \(f(y)\) 为正，就推高这个采样结果；如果 \(f(y)\) 为负，就压低这个采样结果。语言模型里 \(y\) 是一串 token，所以 \(\log\pi_\theta(y)\) 可以拆成每个 token 的 log-prob 之和。MOPD 落到 token 后，\(f(y_t)\) 就是 teacher logp 减 student logp，也就是 advantage。teacher 更认可当前 token，\(f\) 为正；teacher 不认可，\(f\) 为负。因此 score-function trick 的作用不是引入新的 reward，而是把这个评分权重挂到 sampled token 的 log-prob 上，让它可以用普通反向传播更新。

## Slide 19: 反向 KL 推导一：固定前缀与目标

### 页面内容覆盖
- 固定上下文：\(c_t=(x,y_{1:t-1})\)。
- 单位置 Reverse KL：\(L_t=\sum_v \pi_\theta(v\mid c_t)[\log\pi_\theta(v\mid c_t)-\log\pi_{\phi^d}(v\mid c_t)]\)。
- 当前目标：写出一个位置上的 KL 目标。

### 扩写讲稿
先固定上下文 \(c_t=(x,y_{1:t-1})\)。这里只看第 \(t\) 个 token 位置，teacher 冻结，student 可更新。单位置目标 \(L_t\) 是 student 分布对 teacher 分布的反向 KL。这里先不要讲优势函数，只让听众看清楚优化对象是什么。

## Slide 20: 反向 KL 推导二：求导与 baseline

### 页面内容覆盖
- 对 student 求导：\(\nabla_\theta L_t=\mathbb{E}_{v\sim\pi_\theta}[(\log\pi_\theta(v)-\log\pi_{\phi^d}(v)+1)\nabla_\theta\log\pi_\theta(v)]\)。
- baseline 恒等式：\(\mathbb{E}_{v\sim\pi_\theta}[\nabla_\theta\log\pi_\theta(v)]=0\)。
- 这里解释为什么严格求导里的 \(+1\) 不会出现在实现的 advantage 里。

### 扩写讲稿
严格求导会出现 \(\log\pi_\theta-\log\pi_{\phi^d}+1\)，其中 \(+1\) 乘上 score-function 的期望为 0，所以可以看作 baseline。去掉 baseline 后，剩下的 teacher-student log gap 就会成为 advantage 的来源。

## Slide 21: 反向 KL 推导三：采样 token 到 PG loss

### 页面内容覆盖
- 采样 token 上的 advantage：\(A(y_t)=\log\pi_{\phi^d}(y_t\mid c_t)-\log\pi_\theta(y_t\mid c_t)\)，\(\hat A_t=\operatorname{sg}[A(y_t)]\)。
- 对应 PG loss：\(\mathcal L^{PG}_t=-\hat A_t\log\pi_\theta(y_t\mid c_t)\)。
- 结论：Reverse KL 是原始距离；advantage 是它在 student 采样 token 上展开后的更新系数。

### 扩写讲稿
student 采出 \(y_t\) 后，\(A(y_t)=\log\pi_{\phi^d}(y_t\mid c_t)-\log\pi_\theta(y_t\mid c_t)\)。加 stop-gradient 得到实现中的 \(\hat A_t\)。PG loss 写成 \(-\hat A_t\log\pi_\theta(y_t\mid c_t)\)，正 advantage 推高 token，负 advantage 压低 token。

## Slide 22: 实现一：每个 token 的优势函数（advantage）

### 页面内容覆盖
- 方法实现：每个 token 的优势函数（advantage）。先只回答：teacher-student log gap 如何变成一个 token 的更新权重。
- 每个 token 的优势函数：
\[
\hat A_{\mathrm{MOPD},t}
=
\operatorname{sg}\!\left[
\log\pi_{\phi^d}(y_t\mid x,y_{1:t-1})
-
\log\pi_{\theta}(y_t\mid x,y_{1:t-1})
\right]
\]
- 固定同一个前缀 \(x,y_{1:t-1}\)，只看 student 已经采样出来的 token \(y_t\)。
- \(\operatorname{sg}[\cdot]\)：停止梯度。teacher-student gap 只作为固定权重使用；反传不再穿过这个 gap 本身。
- \(\log\pi_{\phi^d}-\log\pi_\theta\)：方向。teacher 更认可当前 token，gap 为正；teacher 更不认可，gap 为负。
- 分数来源：优势函数（advantage）不是额外 reward，而是反向 KL（Reverse KL）在 sampled token 上展开后的 teacher-student log gap。

### 扩写讲稿
先只看 advantage 定义。先固定同一个前缀 \(x,y_{1:t-1}\)，再看 student 已经采样出来的 token \(y_t\)。
优势函数定义为 teacher 对这个 token 的 log-prob 减去 student 对这个 token 的 log-prob，并用 stop-gradient 固定成权重。
如果 teacher 更认可这个 token，\(\hat A_t>0\)，后续更新会推高它；如果 teacher 更不认可，\(\hat A_t<0\)，后续更新会压低它。
这里要强调：优势函数不是新的 reward 模型分数，而是反向 KL 在 student sampled token 上展开后得到的更新系数。
收束时给后续铺垫：后续只讲这个权重如何进入 PG loss，并真正更新 student。

## Slide 23: 实现一：用优势函数（advantage）更新 student

### 页面内容覆盖
- 方法实现：用优势函数（advantage）更新 student。再回答：这个 token 权重如何乘到 student 的 log-prob 上。
- PG loss：
\[
\mathcal{L}^{\mathrm{PG}}_{\mathrm{MOPD}}(\theta)
=
-\mathbb{E}_{x,y}\!\left[
\frac{1}{|y|}\sum_t
\hat A^{\mathrm{clip}}_{\mathrm{MOPD},t}
\log\pi_\theta(y_t\mid x,y_{1:t-1})
\right]
\]
- 优化对象是 student 的 \(\log\pi_\theta(y_t\mid x,y_{1:t-1})\)，不是 teacher。
- \(\hat A^{clip}\)：裁剪后的权重。双边裁剪（two-side clipping）限制极端 log gap，避免单个 token 产生过大更新。
- 负号：把方向翻成最小化目标。\(\hat A_t>0\) 时，增大 \(\log\pi_\theta(y_t)\) 会降低 loss，所以 token 概率被推高。
- 两个步骤合起来读：前文定义“每个 token 的方向和强度”，这里把这个方向真正作用到 student policy 上。

### 扩写讲稿
再看 advantage 如何真正更新 student。
公式里的可更新对象是 \(\log\pi_\theta(y_t\mid x,y_{1:t-1})\)，不是 teacher。
裁剪后的 \(\hat A_t^{clip}\) 作为乘法权重控制方向和强度；正值表示 teacher 更认可当前 token，最小化带负号的 PG loss 会推高这个 token；负值表示 teacher 不认可当前 token，最小化 loss 会压低这个 token。
双边裁剪用于限制极端 gap，避免个别 token 的更新过猛。

## Slide 24: 实现二：Top-k 蒸馏形式

### 页面内容覆盖
- Method §3.2.2 实现二：Top-k 蒸馏形式 Teacher
- payload rank token pϕ 1 v₁ 0.31 2 v₂ 0.18 … … … k=64 vₖ small Bias correction \[\pi_\theta(v)\log\frac{\pi_\theta(v)}{\pi_{\phi^d}(v)}-\pi_\theta(v)+\pi_{\phi^d}(v)\]
- 校正 top-k 截断，使 top-k 内最优点仍是 πθ = πϕᵈ。
- Top-k 只传教师在当前前缀下最看好的 k 个候选 token；完整词表分布和 top-k 重归一化都不进入通信。

### 扩写讲稿
这里右侧的公式需要拆成三块来读。第一块是 \(\pi_\theta(v)\log\frac{\pi_\theta(v)}{\pi_{\phi^d}(v)}\)，它就是 reverse KL 在单个 token 上的原始项，衡量 student 在 token \(v\) 上放的概率和 teacher 给的概率差多少。第二块是 \(-\pi_\theta(v)\)，它不是为了改变 teacher 的偏好，而是为了修正朴素截断带来的梯度偏移；如果没有这一项，对 \(a\log(a/b)\) 求导会多出一个 \(+1\)，导致 \(a=b\) 时仍然有更新压力。第三块是 \(+\pi_{\phi^d}(v)\)，它对 student 参数来说是常数，不改变梯度方向，主要作用是把 \(a=b\) 时的函数值也校准回 0。直观理解就是：第一项负责比较 student 和 teacher，后两项负责让这个比较在 top-k 截断后仍然有正确的停点。
Top-k 实现是论文 3.2.2 给出的另一种实现。
PG 形式每个位置只利用实际 sampled token，因此信号比较轻；Top-k 形式让 teacher 返回每个位置概率最高的 k 个 token，论文默认 k=64，然后只在这些 token 上做 distillation。
难点是：简单截断 reverse KL 会让最优点偏移，student 在 top-k 内会偏离 teacher。
论文因此加入额外的 πϕᵈ(v)-πθ(v)，也就是公式里写成 -πθ(v)+πϕᵈ(v) 的 correction。
这样既保持正确性，又减少 full-vocabulary distillation 传输整个词表分布的通信开销。
Top-k 相关页面要强调工程动机：完整词表分布太大，teacher service 只返回最重要的若干候选 token；correction 项负责让截断后的目标仍然保持正确的最优点。
展开页面内容时，可以按这个顺序讲：Method §3.2.2 实现二：Top-k 蒸馏形式 Teacher；payload rank token pϕ 1 v₁ 0.31 2 v₂ 0.18 … … … k=64 vₖ small Bias correction \[\pi_\theta(v)\log\frac{\pi_\theta(v)}{\pi_{\phi^d}(v)}-\pi_\theta(v)+\pi_{\phi^d}(v)\]；校正 top-k 截断，使 top-k 内最优点仍是 πθ = πϕᵈ。；Top-k 只传教师在当前前缀下最看好的 k 个候选 token；完整词表分布和 top-k 重归一化都不进入通信。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 25: Top-k correction 一：朴素截断的问题

### 页面内容覆盖
- 朴素截断单项：\(g(a,b)=a\log\frac{a}{b}\)，其中 \(a=\pi_\theta(v)\)，\(b=\pi_{\phi^d}(v)\)。
- 梯度：\(g'(a)=\log\frac{a}{b}+1\)，所以 \(a=b\Rightarrow g'(a)=1
e0\)。
- 问题出在梯度，不是函数值：\(a=b\) 时 \(g(a,b)=0\)，但不是驻点。

### 扩写讲稿
单项 \(g(a,b)=a\log(a/b)\) 在 \(a=b\) 时函数值为 0，但导数是 1，所以 \(a=b\) 不是稳定驻点。这说明 top-k 截断破坏了优化方向。

## Slide 26: Top-k correction 二：把驻点修回 teacher

### 页面内容覆盖
- 修正后单项：\(f(a,b)=a\log\frac{a}{b}-a+b\)。
- 修正后梯度：\(f'(a)=\log\frac{a}{b}\)，所以 \(a=b\Rightarrow f'(a)=0\)。
- correction 不是经验补丁，而是为了让 top-k 截断目标仍以 teacher 分布为稳定最优点。

### 扩写讲稿
加入 \(-a+b\) 后，导数变成 \(\log(a/b)\)，因此 \(a=b\) 时梯度为 0。teacher 分布重新成为 top-k 截断目标里的稳定最优点。
## Slide 27: Top-k 截断图：为什么要 correction term？

### 页面内容覆盖
- Method intuition Top-k 截断图：为什么要 correction term？ 切换 naive / corrected，观察最优点是否对齐 teacher naive top-k KL corrected loss teacher top-k student optimum: biased 读这张图只看趋势：朴素截断会让最优解偏离教师分布；论文在 top-k 项里补上 −πθ(v)+πϕᵈ(v)，把这个偏移抵消掉。

### 扩写讲稿
Top-k correction term 的意义是修复截断后的梯度偏移。
只在 top-k 集合上做 reverse KL 会改变最优解；加上线性修正项后，top-k 内的最优点重新对齐 teacher distribution。
Top-k 相关页面要强调工程动机：完整词表分布太大，teacher service 只返回最重要的若干候选 token；correction 项负责让截断后的目标仍然保持正确的最优点。
展开页面内容时，可以按这个顺序讲：Method intuition Top-k 截断图：为什么要 correction term？ 切换 naive / corrected，观察最优点是否对齐 teacher naive top-k KL corrected loss teacher top-k student optimum: biased 读这张图只看趋势：朴素截断会让最优解偏离教师分布；论文在 top-k 项里补上 −πθ(v)+πϕᵈ(v)，把这个偏移抵消掉。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 28: 工程实现：teacher prefill 服务化

### 页面内容覆盖
- Method §3.3 工程实现：teacher prefill 服务化 Student
- sampler 持续生成采样轨迹（rollouts） → RL trainer 异步发起 prefill request → Teacher
- service 返回 token logp / top-k logits → Optimizer 更新 student sampling seq A prefill seq A overlaps sampling seq B update 论文报告：teacher prefill 几乎没有可测 wall-clock overhead。

### 扩写讲稿
工程部分解决的是 teacher prefill 的系统代价。
Stage 3 每条 student 采样轨迹（rollout）都要送到对应 teacher 上算 per-token log-prob 或 top-k logits。
如果把这个过程直接塞进 RL trainer 串行执行，会显著增加训练延迟，也会让 trainer 逻辑更复杂。
作者的做法是把每个领域 teacher 部署成独立 prefill service，类似 RL 训练里的 reward service。
student sampler 持续生成采样轨迹（rollout）；某条 sequence 生成完后，trainer 异步请求 teacher prefill；teacher 返回信号时，其他 sequence 的 sampling 已经在继续进行。
由于 prefill 和 sampling overlap，论文报告 teacher 几乎没有带来可测的 wall-clock overhead。
Top-k 相关页面要强调工程动机：完整词表分布太大，teacher service 只返回最重要的若干候选 token；correction 项负责让截断后的目标仍然保持正确的最优点。
展开页面内容时，可以按这个顺序讲：Method §3.3 工程实现：teacher prefill 服务化 Student；sampler 持续生成采样轨迹（rollouts） → RL trainer 异步发起 prefill request → Teacher；service 返回 token logp / top-k logits → Optimizer 更新 student sampling seq A prefill seq A overlaps sampling seq B update 论文报告：teacher prefill 几乎没有可测 wall-clock overhead。。## Slide 43: 异步 prefill overlap：为什么额外成本可隐藏？

### 页面内容覆盖
- Infrastructure diagram 异步 prefill overlap：为什么额外成本可隐藏？ 点击播放/重置，观察 sampling 与 teacher prefill 的重叠 播放 overlap 重置 Student
- sampling seq A sampling seq B sampling seq C sampling Teacher
- prefill A prefill B prefill Optimizer batch update 看时间轴的重叠部分：教师评分可以藏在下一批学生采样后面；如果教师服务跟不上，请求会排队并形成回压。

### 扩写讲稿
工程优化的关键是让 teacher prefill 与 student sampling 重叠。
teacher prefill 不阻塞下一条序列的 sampling，因此只要 prefill 服务吞吐足够，额外教师计算可以被采样过程隐藏。

展开页面内容时，可以按这个顺序讲：Infrastructure diagram 异步 prefill overlap：为什么额外成本可隐藏？ 点击播放/重置，观察 sampling 与 teacher prefill 的重叠 播放 overlap 重置 Student；sampling seq A sampling seq B sampling seq C sampling Teacher；prefill A prefill B prefill Optimizer batch update 看时间轴的重叠部分：教师评分可以藏在下一批学生采样后面；如果教师服务跟不上，请求会排队并形成回压。。## Slide 44: 4. Experiments

### 页面内容覆盖
- MOPD 是否真的更好？ 4. Experiments 接下来按论文顺序展开这一部分。

### 扩写讲稿
进入实验部分。

展开页面内容时，可以按这个顺序讲：MOPD 是否真的更好？ 4. Experiments 接下来按论文顺序展开这一部分。。## Slide 45: 实验设置

### 页面内容覆盖
- Experiments §4.1 实验设置 Controlled setting Base: Qwen3-30B-A3B-Base Domains: Math / IF / SWE Benchmarks: AIME25/26, IFBench/IFEval, SWE-bench Verified Normalised score \[\tilde{s}_d=\frac{s_d-s_d^{s}}{s_d^{t}-s_d^{s}}\]
- 0 = SFT student；1 = domain specialist teacher。

### 扩写讲稿
实验设置首先保证公平：所有 baseline 和 MOPD 都从同一个 SFT checkpoint 出发，基座是 Qwen3-30B-A3B-Base。
任务覆盖三个领域：Math 用 AIME25 和 AIME26，Instruction Following 用 IFBench 和 IFEval，Software Engineering 用 SWE-bench Verified。
baseline 包括五类思路：Mix-RL 是联合多域 RL；Cascade RL 是按 IF→Math→SWE 顺序级联训练；Off-Policy Finetune 是用 Stage-2 teacher 轨迹做离线 SFT；Param-Merge 包括平均合并和 task arithmetic；最后是 MOPD。
评价时作者使用 normalised score，把 SFT 设为 0，把对应领域 teacher 设为 1，再跨领域平均。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
展开页面内容时，可以按这个顺序讲：Experiments §4.1 实验设置 Controlled setting Base: Qwen3-30B-A3B-Base Domains: Math / IF / SWE Benchmarks: AIME25/26, IFBench/IFEval, SWE-bench Verified Normalised score \[\tilde{s}_d=\frac{s_d-s_d^{s}}{s_d^{t}-s_d^{s}}\]；0 = SFT student；1 = domain specialist teacher。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 29: Appendix A：训练数据来源与长度约束

### 页面内容覆盖
- Training details Appendix A：训练数据来源与长度约束 这些设置解释了各领域 teacher 的训练环境 Domain SFT data RL data Max length / turns Math Mixture-of-Thoughts math subset BigMath、ORZ 等开源数据收集过滤 32,768 tokens Instruction Following 按 IFBench 方法构造，并用 gpt-oss-120b 蒸馏 按 IFBench recipe 合成 32,768 tokens Software Engineering R2E-Gym tasks，经开源模型蒸馏 R2E-Gym-Lite 65,536 tokens；≤50 interaction turns SWE 的上下文和交互约束更重，因此后续 batch size 与 sample budget 也不同。

### 扩写讲稿
这里来自 Appendix A 的 Training data。
Math 的 SFT 主要来自 Mixture-of-Thoughts 的数学子集，RL 数据来自 BigMath、ORZ 等开源数据的收集和过滤。
IF 的 SFT prompts 按 IFBench 方法构造，并在 gpt-oss-120b 上蒸馏；RL 数据也按 IFBench recipe 合成。
SWE 的 SFT 数据来自 R2E-Gym tasks，通过开源模型蒸馏，RL 用 R2E-Gym-Lite。
注意 SWE 最大长度是 65,536，并限制最多 50 轮交互，这说明软件工程任务比数学和 IF 更长、更像 agent 环境。

展开页面内容时，可以按这个顺序讲：Training details Appendix A：训练数据来源与长度约束 这些设置解释了各领域 teacher 的训练环境 Domain SFT data RL data Max length / turns Math Mixture-of-Thoughts math subset BigMath、ORZ 等开源数据收集过滤 32,768 tokens Instruction Following 按 IFBench 方法构造，并用 gpt-oss-120b 蒸馏 按 IFBench recipe 合成 32,768 tokens Software Engineering R2E-Gym tasks，经开源模型蒸馏 R2E-Gym-Lite 65,536 tokens；≤50 interaction turns SWE 的上下文和交互约束更重，因此后续 batch size 与 sample budget 也不同。。## Slide 47: Appendix A：RL / MOPD 超参数全表

### 页面内容覆盖
- Training details Appendix A：RL / MOPD 超参数全表 论文中所有关键训练设置集中在这里 Setting Algorithm / LR BS N 采样轨迹（rollouts） Budget / Ratio Per-domain Math / IF RL GRPO + Dynamic Sampling；LR=3e-6 144 8 ≈175K sequences Per-domain SWE RL GRPO + Dynamic Sampling；LR=3e-6 80 8 ≈150K sequences Cascade RL 同 per-domain RL 同上 8 顺序 IF→Math→SWE Mix-RL GRPO；LR=4e-6 256 8 Math:IF:SWE = 0.35:0.35:0.30 MOPD 无 Dynamic Sampling；PG/Top-k distill 2048 1 Math:IF:SWE = 0.35:0.35:0.30 三个容易混淆的开关：Dynamic Sampling 只用于 per-domain RL；MOPD 明确不用；PG 里 Amax=5，Top-k 里 k=64。
- Dynamic Sampling 属于哪一行 论文把 Dynamic Sampling 写在 per-domain RL 设置里；MOPD 行写的是无 Dynamic Sampling、BS=2048、N=1。
- \(\text{sample}\rightarrow\text{one update}\rightarrow\text{discard}\)

### 扩写讲稿
这里是 Appendix A 的 hyperparameters。
Per-domain RL 使用 on-policy GRPO 加 Dynamic Sampling，所谓 Dynamic Sampling 是 采样轨迹（rollout）产生的数据只做一次 gradient update 然后丢弃。
Math 和 IF 的 batch size 是 144，每个 prompt 采 8 条 采样轨迹（rollout），约 175K sequences；SWE batch size 是 80，也采 8 条 采样轨迹（rollout），约 150K sequences。
Mix-RL 学习率更高，为 4e-6，batch size 256，域配比是 0.35:0.35:0.3。
MOPD 则不使用 Dynamic Sampling，batch size 2048，N=1，也使用同样域配比。
PG 的优势函数（advantage） clip Amax=5，Top-k 的 k=64。
这里要把公式翻译成训练动作：teacher-student log gap 决定方向，student 的 log-prob 决定可更新对象，停止梯度（stop-gradient）和 clipping 控制这个训练信号的稳定性。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
展开页面内容时，可以按这个顺序讲：Training details Appendix A：RL / MOPD 超参数全表 论文中所有关键训练设置集中在这里 Setting Algorithm / LR BS N 采样轨迹（rollouts） Budget / Ratio Per-domain Math / IF RL GRPO + Dynamic Sampling；LR=3e-6 144 8 ≈175K sequences Per-domain SWE RL GRPO + Dynamic Sampling；LR=3e-6 80 8 ≈150K sequences Cascade RL 同 per-domain RL 同上 8 顺序 IF→Math→SWE Mix-RL GRPO；LR=4e-6 256 8 Math:IF:SWE = 0.35:0.35:0.30 MOPD 无 Dynamic Sampling；PG/Top-k distill 2048 1 Math:IF:SWE = 0.35:0.35:0.30 三个容易混淆的开关：Dynamic Sampling 只用于 per-domain RL；MOPD 明确不用；PG 里 Amax=5，Top-k 里 k=64。；Dynamic Sampling 属于哪一行 论文把 Dynamic Sampling 写在 per-domain RL 设置里；MOPD 行写的是无 Dynamic Sampling、BS=2048、N=1。；\(\text{sample}\rightarrow\text{one update}\rightarrow\text{discard}\)。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。
补充说明：Dynamic Sampling 属于哪一行： 论文把 Dynamic Sampling 写在 per-domain RL 设置里；MOPD 行写的是无 Dynamic Sampling、BS=2048、N=1。 流程：sample → one update → discard

## Slide 30: MOPD 的 BS=2048、N=1 解释

### 页面内容覆盖
- Training details MOPD 的 BS=2048、N=1 解释 这是 teacher-scored distillation 的训练设置 Domain RL / Mix-RL 依赖 reward 和优势函数估计（advantage estimation）每个 prompt 采 N=8 采样轨迹（rollouts） Dynamic Sampling：数据只更新一次 MOPD teacher 在每个 token 直接给 dense log-prob 信号 N=1 也能得到足够密集的监督 BS=2048 提高吞吐与 teacher prefill 批处理效率

### 扩写讲稿
训练设置背后的方法差异体现在 rollout 数量和 batch 设计上。
普通 RL 需要多个 采样轨迹（rollouts）来估计同一 prompt 下不同输出的好坏，所以 N=8。
MOPD 的监督来自 teacher 对每个 token 的概率信号，不依赖同一个 prompt 的多样本比较，因此 N=1 也合理。
与此同时，大 batch 可以提高蒸馏稳定性和 teacher prefill 服务吞吐。
从超参设置可以看出它们训练范式不同。
这里要把公式翻译成训练动作：teacher-student log gap 决定方向，student 的 log-prob 决定可更新对象，停止梯度（stop-gradient）和 clipping 控制这个训练信号的稳定性。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：Training details MOPD 的 BS=2048、N=1 解释 这是 teacher-scored distillation 的训练设置 Domain RL / Mix-RL 依赖 reward 和优势函数估计（advantage estimation）每个 prompt 采 N=8 采样轨迹（rollouts） Dynamic Sampling：数据只更新一次 MOPD teacher 在每个 token 直接给 dense log-prob 信号 N=1 也能得到足够密集的监督 BS=2048 提高吞吐与 teacher prefill 批处理效率。## Slide 49: Appendix B：评测协议

### 页面内容覆盖
- Evaluation details Appendix B：评测协议 避免把采样噪声误读为方法差异 Math AIME25 / AIME26 每题采样 32 次，报告 avg@32，用于降低高难数学小样本方差。
- IF IFBench / IFEval 每个问题评测 1 次。
- SWE SWE-bench Verified 每个任务评测 1 次。
- Protocol Decoding 所有 benchmark temperature=1.0，不使用 top-p 或 top-k 截断。

### 扩写讲稿
这里来自 Appendix B。
数学任务 AIME25/AIME26 因为题目数少且难度高，单次采样方差大，所以每题采样 32 次并报告 avg@32。
IFBench、IFEval 和 SWE-bench Verified 都每题或每任务评测一次。
所有 benchmark 解码温度为 1.0，不使用 top-p 或 top-k 截断，避免不同截断策略影响方法比较。
Top-k 相关页面要强调工程动机：完整词表分布太大，teacher service 只返回最重要的若干候选 token；correction 项负责让截断后的目标仍然保持正确的最优点。
展开页面内容时，可以按这个顺序讲：Evaluation details Appendix B：评测协议 避免把采样噪声误读为方法差异 Math AIME25 / AIME26 每题采样 32 次，报告 avg@32，用于降低高难数学小样本方差。；IF IFBench / IFEval 每个问题评测 1 次。；SWE SWE-bench Verified 每个任务评测 1 次。；Protocol Decoding 所有 benchmark temperature=1.0，不使用 top-p 或 top-k 截断。。## Slide 50: 详解：归一化分数（Normalized Score）怎么读？

### 页面内容覆盖
- Metric detail 详解：归一化分数（Normalized Score）怎么读？ 把不同领域的 headroom 放到同一把尺子上 \[\tilde{s}_d=\frac{s_d-s_d^{\mathrm{SFT}}}{s_d^{\mathrm{Teacher}}-s_d^{\mathrm{SFT}}}\]
- 0 SFT 0.5 close 50% 1 Teacher
- 为什么不用 raw accuracy 平均？ 不同领域 headroom 不同，直接平均会偏向提升空间（headroom）大的领域。
- 0.937 的意思 平均来看，MOPD 吸收了约 93.7% 的 teacher headroom。
- >1 怎么读？ 超过对应 teacher，常见于共享能力迁移、采样方差或跨域互补。
- <0 怎么读？ 低于 SFT baseline，后面的外部 teacher 消融会出现这种情况。

### 扩写讲稿
这里专门解释归一化分数（normalized score）。
它把每个领域从 SFT 到 teacher 的提升空间（headroom）归一化。
0 表示没超过 SFT，1 表示达到领域 teacher，超过 1 表示超过 teacher，低于 0 表示退到 SFT baseline 以下。
主结果的综合分可以理解成先按领域归一化，再跨领域汇总比较。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
展开页面内容时，可以按这个顺序讲：Metric detail 详解：归一化分数（Normalized Score）怎么读？ 把不同领域的 headroom 放到同一把尺子上 \[\tilde{s}_d=\frac{s_d-s_d^{\mathrm{SFT}}}{s_d^{\mathrm{Teacher}}-s_d^{\mathrm{SFT}}}\]；0 SFT 0.5 close 50% 1 Teacher；为什么不用 raw accuracy 平均？ 不同领域 headroom 不同，直接平均会偏向提升空间（headroom）大的领域。；0.937 的意思 平均来看，MOPD 吸收了约 93.7% 的 teacher headroom。；>1 怎么读？ 超过对应 teacher，常见于共享能力迁移、采样方差或跨域互补。；<0 怎么读？ 低于 SFT baseline，后面的外部 teacher 消融会出现这种情况。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 31: 主结果：MOPD 综合最优且均衡

### 页面内容覆盖
- Experiments §4.2 主结果：MOPD 综合最优且均衡 Method AIME25 AIME26 IFBench IFEval SWE Norm Student
- 45.42 54.48 42.69 84.17 35.80 0.000 RL Teacher
- 54.79 63.65 78.40 95.50 51.20 1.000 Mix-RL 52.71 63.75 75.00 94.58 48.80 0.882 Cascade 48.54 61.88 77.11 95.80 47.80 0.775 Off-Policy 51.56 63.44 80.95 93.35 45.80 0.824 Task Arith. 49.38 63.96 78.23 95.81 48.80 0.857 MOPD 51.46 65.31 77.89 93.84 50.40 0.937 Norm score Mix-RL 0.882 Cascade 0.775 Off-Policy 0.824 Task Arith. 0.857 MOPD 0.937 MOPD 领先 Mix-RL 约 5.5 个归一化点；三领域 headroom close 更均衡。
- 读表顺序：先看 Norm，再回到 Math / IF / SWE 三类指标看是否均衡。MOPD 三个领域约 close 91–95% teacher headroom。

### 扩写讲稿
主结果来自 Table 2。
MOPD 的 normalised score 是 0.9373，高于最强 baseline Mix-RL 的 0.8818，领先大约 5.5 个归一化点。
这个提升同时体现在总分和均衡性上。
论文强调，MOPD 在三个领域的归一化分数（normalized score）都落在 0.91 到 0.95 之间，也就是每个领域都吸收了大部分 teacher headroom。
相比之下，Cascade RL 受训练顺序影响，Math 在后续 SWE 阶段会退化；Off-Policy Finetune 在 IF 上甚至超过 teacher，SWE 只 close 约 65%；Param-Merge 则对合并 recipe 很敏感。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
展开页面内容时，可以按这个顺序讲：Experiments §4.2 主结果：MOPD 综合最优且均衡 Method AIME25 AIME26 IFBench IFEval SWE Norm Student；45.42 54.48 42.69 84.17 35.80 0.000 RL Teacher；54.79 63.65 78.40 95.50 51.20 1.000 Mix-RL 52.71 63.75 75.00 94.58 48.80 0.882 Cascade 48.54 61.88 77.11 95.80 47.80 0.775 Off-Policy 51.56 63.44 80.95 93.35 45.80 0.824 Task Arith. 49.38 63.96 78.23 95.81 48.80 0.857 MOPD 51.46 65.31 77.89 93.84 50.40 0.937 Norm score Mix-RL 0.882 Cascade 0.775 Off-Policy 0.824 Task Arith. 0.857 MOPD 0.937 MOPD 领先 Mix-RL 约 5.5 个归一化点；三领域 headroom close 更均衡。；读表顺序：先看 Norm，再回到 Math / IF / SWE 三类指标看是否均衡。MOPD 三个领域约 close 91–95% teacher headroom。。## Slide 52: 实验结论一：Table 2 到底证明了什么？

### 页面内容覆盖
- Experiments conclusion 实验结论一：Table 2 到底证明了什么？ 关键读法：统一模型是否均衡接近多个教师 读表问题 表中证据 结论 综合能力是否最高？ MOPD Norm=0.937，最强 baseline Mix-RL=0.882 MOPD 是综合分最高的能力集成（capability integration）方法，领先约 5.5 个归一化点 有没有牺牲某个领域？ Math≈91% headroom，IF≈95%，SWE≈95% 提升比较均衡，目标是接近所有 teacher，避免单点刷高 Off-Policy 为什么不够？ IF 很高，但 SWE 只有 45.8；SWE headroom close 约 65% 离线 teacher 轨迹能给密集监督，复杂交互任务上仍受前缀错位影响 Mix-RL 为什么落后？ 各域联合 RL 的 Norm=0.882，低于 MOPD 原始 reward / 优势函数（advantage）混在同一训练里，跨域信号干扰仍然存在 Param-Merge 说明什么？ Task Arithmetic Norm=0.857，平均合并更低 权重空间融合（weight-space merging）能并行，但合并 recipe 敏感，难稳定贴近所有 teacher 这张表支持的核心结论：MOPD 把多个单域 teacher 的 headroom 更稳定地吸收到一个统一 student 里。

### 扩写讲稿
这里把 Table 2 的实验结论展开。
读这张表不能只看某个 benchmark 的最高数字，应该看 Norm 和三类能力是否均衡。
MOPD 的 Norm 最高，并且 Math、IF、SWE 都接近各自 teacher 的大部分提升空间（headroom）。
Off-Policy 在 IF 上很强，但 SWE 明显偏弱，说明 teacher trajectory 的离线监督在复杂交互任务上仍会吃亏。
Mix-RL 和 Param-Merge 分别对应跨域 reward 干扰与权重空间融合（weight-space merging）不稳定。
这里要把公式翻译成训练动作：teacher-student log gap 决定方向，student 的 log-prob 决定可更新对象，停止梯度（stop-gradient）和 clipping 控制这个训练信号的稳定性。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：Experiments conclusion 实验结论一：Table 2 到底证明了什么？ 关键读法：统一模型是否均衡接近多个教师 读表问题 表中证据 结论 综合能力是否最高？ MOPD Norm=0.937，最强 baseline Mix-RL=0.882 MOPD 是综合分最高的能力集成（capability integration）方法，领先约 5.5 个归一化点 有没有牺牲某个领域？ Math≈91% headroom，IF≈95%，SWE≈95% 提升比较均衡，目标是接近所有 teacher，避免单点刷高 Off-Policy 为什么不够？ IF 很高，但 SWE 只有 45.8；SWE headroom close 约 65% 离线 teacher 轨迹能给密集监督，复杂交互任务上仍受前缀错位影响 Mix-RL 为什么落后？ 各域联合 RL 的 Norm=0.882，低于 MOPD 原始 reward / 优势函数（advantage）混在同一训练里，跨域信号干扰仍然存在 Param-Merge 说明什么？ Task Arithmetic Norm=0.857，平均合并更低 权重空间融合（weight-space merging）能并行，但合并 recipe 敏感，难稳定贴近所有 teacher 这张表支持的核心结论：MOPD 把多个单域 teacher 的 headroom 更稳定地吸收到一个统一 student 里。。## Slide 53: 交互式结果阅读器：不同 baseline 输在哪里？

### 页面内容覆盖
- Experiments reader 交互式结果阅读器：不同 baseline 输在哪里？ 点击方法名，突出对应失败模式 MOPD Mix-RL Cascade RL Off-Policy FT Param-Merge / Task Arith. Math IF SWE 0=SFT 1=Teacher
- MOPD 三个领域均衡 close 91–95% teacher headroom，综合 norm score 0.937。

### 扩写讲稿
主结果可以按 baseline 机制逐项解释。
点击不同 baseline：Mix-RL 相对均衡，整体分数较低；Cascade 受训练顺序影响；Off-Policy FT 在 SWE 上弱；Param-Merge 对 merge recipe 敏感；MOPD 则更均衡。

展开页面内容时，可以按这个顺序讲：Experiments reader 交互式结果阅读器：不同 baseline 输在哪里？ 点击方法名，突出对应失败模式 MOPD Mix-RL Cascade RL Off-Policy FT Param-Merge / Task Arith. Math IF SWE 0=SFT 1=Teacher；MOPD 三个领域均衡 close 91–95% teacher headroom，综合 norm score 0.937。。## Slide 54: 训练动态：样本效率更高

### 页面内容覆盖
- Experiments §4.2 论文 Figure 2：训练动态与样本效率 原图展示 IF / Math / SWE 三个领域随训练样本增长的 accuracy。
- 读图提示：IF 中 MOPD 很早到达 teacher-level plateau；Math 中 MOPD 与 teacher 轨迹接近；SWE 中 MOPD 更快接近 teacher，Mix-RL 需要更长 sample budget。

### 扩写讲稿
这里放论文 Figure 2 原图，说明 MOPD 的样本效率。
三个子图分别是 Instruction Following、Math 和 SWE。横轴是每个领域消耗的训练样本数，纵轴是领域 accuracy。
论文观察到，MOPD 在 IF 上大约 25K samples 就到 teacher-level plateau，在 SWE 上大约 30K samples 达到 plateau；而 Mix-RL 通常需要完整 150K 到 180K per-domain sample budget 才接近类似水平。
这和方法设计一致：普通 RL 依赖稀疏 outcome reward，一条轨迹可能只有一个整体反馈；MOPD 的 teacher 在每个 token 都给 log-probability 信号，所以优化更密集、方差更低，因而更 sample-efficient。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
展开页面内容时，可以按这个顺序讲：Experiments §4.2 论文 Figure 2：训练动态与样本效率；先读三个子图标题，再读横轴和纵轴，最后比较 MOPD、Mix-RL、Cascade-RL 和 teacher 曲线。## Slide 55: 实验结论二：为什么 MOPD 样本效率更高？

### 页面内容覆盖
- Experiments conclusion 实验结论二：为什么 MOPD 样本效率更高？ Figure 2 的重点是 dense teacher signal 缩短了信用分配链条 现象 1 IF 很快到平台 论文报告 MOPD 在 IF 上约 25K samples 达到 teacher-level plateau。
- 现象 2 SWE 也更快 SWE 上约 30K samples 达到 plateau，Mix-RL 通常用完整 150K–180K budget。
- 机制 原因在信号密度 普通 RL 多依赖 trajectory-level reward；MOPD 每个 token 都拿到 teacher log-prob。
- 这说明实验优势不只来自更多算力或更长训练；MOPD 把稀疏结果反馈改成逐 token 教师监督，优化路径更短、方差更低。

### 扩写讲稿
Figure 2 的实验结论是 MOPD 在多个领域更快接近平台区。
MOPD 在 IF 和 SWE 上更早达到平台区，关键原因是每个 token 都有 teacher log-prob 信号。
普通 RL 需要从最终 reward 回推整条轨迹里哪些 token 有用，信用分配链条更长。
MOPD 直接在 student 已访问的每个前缀位置比较 student 和 teacher 分布，所以样本效率更高。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
展开页面内容时，可以按这个顺序讲：Experiments conclusion 实验结论二：为什么 MOPD 样本效率更高？ Figure 2 的重点是 dense teacher signal 缩短了信用分配链条 现象 1 IF 很快到平台 论文报告 MOPD 在 IF 上约 25K samples 达到 teacher-level plateau。；现象 2 SWE 也更快 SWE 上约 30K samples 达到 plateau，Mix-RL 通常用完整 150K–180K budget。；机制 原因在信号密度 普通 RL 多依赖 trajectory-level reward；MOPD 每个 token 都拿到 teacher log-prob。；这说明实验优势不只来自更多算力或更长训练；MOPD 把稀疏结果反馈改成逐 token 教师监督，优化路径更短、方差更低。。## Slide 56: 工业规模：MiMo-V2-Flash

### 页面内容覆盖
- Experiments §4.3 工业规模：MiMo-V2-Flash AIME25 HMMT25 LCB IFBench SWE-V τ2-B τ2-T Student
- 89.3 76.9 77.5 55.4 67.8 75.9 92.7 Teacher
- 93.9 82.6 82.6 68.9 74.2 79.6 95.0 MOPD 94.1 84.4 83.2 66.7 73.4 80.3 95.3 Δ +0.2 +1.8 +0.6 −2.2 −0.8 +0.7 +0.3 重点：同一 recipe 可迁移到工业级 frontier model，多数 benchmark 匹配或超过 teacher。
- 缩写：LCB = LiveCodeBench；τ²-B = τ²-Bench；τ²-T = τ²-Telecom。个别 benchmark 超过 teacher，可能来自共享能力、评测方差或跨域迁移。

### 扩写讲稿
第 4.3 节把 MOPD 用到 MiMo-V2-Flash，这是工业规模 frontier model。
Table 3 显示，MOPD 在 AIME25、HMMT25、LCB、τ2-Bench、τ2-Telecom 上超过对应 teacher，在 IFBench 和 SWE-Bench Verified 上略低于 teacher。
这里要传达的重点是同一套 pipeline 能迁移到大规模生产模型上。
也就是说，MOPD 是能服务真实 post-training 流程的能力集成（capability integration）范式。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
展开页面内容时，可以按这个顺序讲：Experiments §4.3 工业规模：MiMo-V2-Flash AIME25 HMMT25 LCB IFBench SWE-V τ2-B τ2-T Student；89.3 76.9 77.5 55.4 67.8 75.9 92.7 Teacher；93.9 82.6 82.6 68.9 74.2 79.6 95.0 MOPD 94.1 84.4 83.2 66.7 73.4 80.3 95.3 Δ +0.2 +1.8 +0.6 −2.2 −0.8 +0.7 +0.3 重点：同一 recipe 可迁移到工业级 frontier model，多数 benchmark 匹配或超过 teacher。；缩写：LCB = LiveCodeBench；τ²-B = τ²-Bench；τ²-T = τ²-Telecom。个别 benchmark 超过 teacher，可能来自共享能力、评测方差或跨域迁移。。## Slide 57: 实验结论三：MiMo 结果说明什么？

### 页面内容覆盖
- Experiments conclusion 实验结论三：MiMo 结果说明什么？ 从 controlled setting 走到工业规模模型 支持的结论 同一套三阶段流程可以迁移到 309B 级别模型。
- 覆盖能力从 3 类扩展到 Math / Code / IF / SWE / Tool Use 5 类。
- 7 个指标里 5 个达到或超过对应 teacher。
- 不能过度解读 IFBench 和 SWE-Bench Verified 仍略低于 teacher。
- 超过 teacher 的指标可能包含共享能力迁移和评测方差。
- 它证明可扩展性，不等于证明所有领域都能无损融合。
- 这组实验的价值在外推：MOPD 不只在 Qwen3 controlled setting 有效，也能进入真实大模型 post-training 工作流。

### 扩写讲稿
MiMo-V2-Flash 实验的结论边界在于它验证可扩展性，同时仍保留个别领域差距。
正向结论是：同一 recipe 可以扩展到工业级 309B 模型，并覆盖五类能力；七个指标中五个匹配或超过 teacher。
边界是：IFBench 和 SWE-Bench Verified 仍低于对应 teacher，超过 teacher 的指标也可能包含共享能力迁移和评测方差。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
讲流程页时要按数据流走：prompt 从哪里来，student 什么时候生成，teacher 什么时候打分，optimizer 拿到什么信号。这样听众能把每个模块和后面的公式对应起来。
展开页面内容时，可以按这个顺序讲：Experiments conclusion 实验结论三：MiMo 结果说明什么？ 从 controlled setting 走到工业规模模型 支持的结论 同一套三阶段流程可以迁移到 309B 级别模型。；覆盖能力从 3 类扩展到 Math / Code / IF / SWE / Tool Use 5 类。；7 个指标里 5 个达到或超过对应 teacher。；不能过度解读 IFBench 和 SWE-Bench Verified 仍略低于 teacher。；超过 teacher 的指标可能包含共享能力迁移和评测方差。；它证明可扩展性，不等于证明所有领域都能无损融合。。## Slide 58: MiMo-V2-Flash：工业部署覆盖的能力域

### 页面内容覆盖
- Experiments §4.3 MiMo-V2-Flash：工业部署覆盖的能力域 论文这里比 Qwen3 controlled setting 覆盖更多能力 teacher Math AIME25、HMMT25 teacher Code LCB teacher Instruction Following IFBench teacher SWE SWE-Bench Verified teacher Tool Use τ²-Bench、τ²-Telecom Qwen3 实验是 3 域 controlled comparison；MiMo-V2-Flash 是 5 类能力的完整工业 pipeline。

### 扩写讲稿
这里补充 §4.3 的一个细节：MiMo-V2-Flash 覆盖 Math、IF、SWE、Code 和 Tool Use。
表里的 LCB 对应代码能力，τ²-Bench 和 τ²-Telecom 对应工具使用能力。
这个结果说明 MOPD 的 prompt-routed multi-teacher 设计可以自然扩展到更多 domain。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
展开页面内容时，可以按这个顺序讲：Experiments §4.3 MiMo-V2-Flash：工业部署覆盖的能力域 论文这里比 Qwen3 controlled setting 覆盖更多能力 teacher Math AIME25、HMMT25 teacher Code LCB teacher Instruction Following IFBench teacher SWE SWE-Bench Verified teacher Tool Use τ²-Bench、τ²-Telecom Qwen3 实验是 3 域 controlled comparison；MiMo-V2-Flash 是 5 类能力的完整工业 pipeline。。## Slide 59: 5. Analysis

### 页面内容覆盖
- 方法为什么稳定？ 5. Analysis 接下来按论文顺序展开这一部分。

### 扩写讲稿
进入分析部分。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：方法为什么稳定？ 5. Analysis 接下来按论文顺序展开这一部分。。## Slide 60: 消融一：PG vs Top-k

### 页面内容覆盖
- Analysis §4.4.1 消融一：PG vs Top-k Teacher
- Loss Norm RL Teacher
- PG 0.937 RL Teacher
- Top-k 0.909 现象 两条训练轨迹接近重合 initial KL ≈ 0.04 entropy ≈ 0.30 稳定 这里的关键信息是 same-origin：教师和学生距离很近，只看学生已采样 token 的教师打分，通常已经能给出有效方向。

### 扩写讲稿
第一个分析比较两种 loss：policy-gradient 形式和 Top-k distillation 形式。
在 same-origin RL teachers 下，两种方法训练都稳定：Math accuracy 平滑上升，student-teacher reverse KL 从大约 0.04 的低初值单调下降，policy entropy 稳定在约 0.30。
结果上 PG 的 norm score 是 0.937，Top-k 是 0.909，整体仍保持可比水平。
作者的解释是：当 teacher 和 student 同源时，student 采样轨迹（rollout）本来就集中在 teacher 高概率区域，PG 只看 sampled token 也能得到足够有信息量的梯度，因此 Top-k 没有带来明显额外稳定性。
Top-k 相关页面要强调工程动机：完整词表分布太大，teacher service 只返回最重要的若干候选 token；correction 项负责让截断后的目标仍然保持正确的最优点。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：Analysis §4.4.1 消融一：PG vs Top-k Teacher；Loss Norm RL Teacher；PG 0.937 RL Teacher；Top-k 0.909 现象 两条训练轨迹接近重合 initial KL ≈ 0.04 entropy ≈ 0.30 稳定 这里的关键信息是 same-origin：教师和学生距离很近，只看学生已采样 token 的教师打分，通常已经能给出有效方向。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 32: 消融二：为什么 same-origin 关键？

### 页面内容覆盖
- Analysis §4.4.2 论文 Figure 3：same-origin teacher 为什么关键？ 外部强 teacher 看似更强，实际可能带来 KL 放大、熵收缩和训练崩溃。
- 原图读法：左图看 Math accuracy，中图看 student-teacher KL，右图看 policy entropy；虚线是外部 Qwen3-235B-A22B teacher。
- 读图提示：外部 teacher 配置后期 accuracy 退化；KL 初始距离约 0.19，高于同源约 0.04；策略熵从约 0.30 收缩到 0.21。

### 扩写讲稿
第二个分析是整篇论文最关键的稳定性消融，这里直接放论文 Figure 3 原图。
作者把 Math teacher 换成能力更强且分布不同的 Qwen3-235B-A22B，其他 IF 和 SWE teacher、数据、超参保持不变。
读图时先看左图 Math accuracy。外部 teacher 对应的虚线配置后期明显退化。
再看中图 student-teacher KL。外部 teacher 的初始 per-token KL 大约是 0.19，而 same-origin 只有约 0.04，差了约 5 倍。
KL 大意味着 student 采样轨迹（rollout）经常位于 teacher 低概率区域，teacher 给出的信号更像大量惩罚。
策略梯度（Policy Gradient, PG）下学生策略熵从 0.30 收缩到 0.21；Top-k 下训练在 step 18 附近发生灾难性崩溃。
这里的学生策略熵指 student 在每个位置对下一个 token 的概率分布有多分散。可以用公式 \(H(\pi_\theta)=-\sum_v \pi_\theta(v)\log \pi_\theta(v)\) 来读：熵高表示模型保留多个候选 token；熵低表示概率集中到少数 token。0.30 收缩到 0.21 表示分布变尖，模型更早锁死少数候选，这在外部 teacher 场景中是稳定性警告。
Top-k 相关页面要强调工程动机：完整词表分布太大，teacher service 只返回最重要的若干候选 token；correction 项负责让截断后的目标仍然保持正确的最优点。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：Analysis §4.4.2 论文 Figure 3：same-origin teacher 为什么关键？先读左图 accuracy，再读中图 KL，最后读右图 policy entropy；下方三条读图提示对应退化、KL 放大和策略熵收缩。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 33: 详解：外部强 teacher 为什么会把训练带崩？

### 页面内容覆盖
- Analysis detail 详解：外部强 teacher 为什么会把训练带崩？ 把论文 Figure 3 背后的因果链拆出来 1. Teacher
- 更强且不同源 Qwen3-235B-A22B 数学能力强，策略分布与 student 差距大。
- 2. 初始 KL 变大 约 0.19 vs same-origin 的约 0.04，student 采样轨迹（rollout）常落在 teacher 低概率区域。
- 3. 梯度变“惩罚性” 大量 token 收到负向 gap，学生策略熵从约 0.30 收缩到 0.21。
- 4. 性能退化 / collapse 策略梯度（Policy Gradient, PG）退化到 0.600；Top-k 在 step 18 附近灾难性崩溃。
- 学生策略熵是什么？它衡量 student 在下一个 token 上的概率分布有多分散：\(H(\pi_\theta)=-\sum_v \pi_\theta(v)\log\pi_\theta(v)\)。熵高表示模型还保留多个候选；熵低表示概率集中到少数 token。
- 0.30 → 0.21 怎么读？分布变尖，模型更早地锁死少数 token。这里不是“更自信所以更好”，而是外部 teacher 带来的负向信号让 student 变得过度保守，属于稳定性警告。

### 扩写讲稿
这里拆 same-origin 消融的因果链。
重点是 teacher 适合蒸馏需要 policy distribution 对齐；如果 teacher 与 student policy 支持集错位，on-policy distillation 会收到大量惩罚信号。
讲实验页时不要只读数字。先说明指标怎么归一化，再说明每个 baseline 的失败模式是否和前文方法分析一致，最后说明这些结果能支持到什么程度。
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：Analysis detail 详解：外部强 teacher 为什么会把训练带崩？ 把论文 Figure 3 背后的因果链拆出来 1. Teacher；更强且不同源 Qwen3-235B-A22B 数学能力强，策略分布与 student 差距大。；2. 初始 KL 变大 约 0.19 vs same-origin 的约 0.04，student 采样轨迹（rollout）常落在 teacher 低概率区域。；3. 梯度变“惩罚性” 大量 token 收到负向 gap，学生策略熵从约 0.30 收缩到 0.21。；4. 性能退化 / collapse 策略梯度（Policy Gradient, PG）退化到 0.600；Top-k 在 step 18 附近灾难性崩溃。；学生策略熵是什么？它衡量 student 在下一个 token 上的概率分布有多分散；0.30 → 0.21 怎么读？分布变尖，模型更早地锁死少数 token。。遇到公式时先读变量含义，再读求和或期望范围，最后读优化方向。不要让听众直接从符号跳到结论。

## Slide 34: 多轮演化：继续吸收新 teacher 能力

### 页面内容覆盖
- Analysis §4.4.3 多轮演化：继续吸收新 teacher 能力 Iter-1 MOPD student student norm 0.937 → Init Iter-2 teachers + student 重新建立 shared origin → Iter-2 RL teachers teacher norm 1.030 → Iter-2 MOPD student student norm 0.986 读这个环：上一轮集成出的学生，下一轮同时作为新教师训练和新学生集成的起点。

### 扩写讲稿
第 4.4.3 讨论 multi-round student-teacher evolution。
第一轮 MOPD 后，student 已经吸收了大部分 teacher headroom，Math 和 IF 仍有继续提升空间（headroom）。
作者于是把 Iter-1 MOPD student 作为下一轮 teacher RL 的初始化，再训练 Iter-2 domain teachers，然后进行第二轮 MOPD。
结果是 Iter-2 RL Teacher 的 norm score 达到 1.030，说明从更强 student 出发继续做领域 RL 可以产生更强 teacher；Iter-2 MOPD 的 norm score 从 0.937 提升到 0.986。
这个实验说明 MOPD 可以形成循环：统一模型变强后，再生产更强 teacher，再把能力集成（capability integration）回来。

展开页面内容时，可以按这个顺序讲：Analysis §4.4.3 多轮演化：继续吸收新 teacher 能力 Iter-1 MOPD student student norm 0.937 → Init Iter-2 teachers + student 重新建立 shared origin → Iter-2 RL teachers teacher norm 1.030 → Iter-2 MOPD student student norm 0.986 读这个环：上一轮集成出的学生，下一轮同时作为新教师训练和新学生集成的起点。。## Slide 64: 6. Discussion

### 页面内容覆盖
- 算法与工作流 6. Discussion 接下来按论文顺序展开这一部分。

### 扩写讲稿
进入讨论部分。

展开页面内容时，可以按这个顺序讲：算法与工作流 6. Discussion 接下来按论文顺序展开这一部分。。## Slide 65: Discussion：组织工程价值

### 页面内容覆盖
- Discussion §5 Discussion：组织工程价值 workflow Parallel development 各领域团队并行迭代 reward、data、sandbox。
- recipe Recipe decoupling 每个领域可选不同 RL 算法、采样轨迹（rollout）过程和超参。
- risk Risk isolation 单域失败只重启单域 teacher，不拖垮全局 run。
- 工程结论：先分领域生产能力，再用统一学生模型吸收这些能力。

### 扩写讲稿
Discussion 部分强调 MOPD 的组织工程价值。
传统 joint multi-domain RL 把所有领域的 reward、采样轨迹（rollout）、数据比例和超参耦合在一次大训练中；如果某个领域 reward 需要重调，整个 multi-domain run 可能都要重启。
MOPD 把 capability production 和 capability integration 拆开。
Stage 2 中，各领域团队可以并行训练自己的 teacher，recipe-level 完全解耦；某个领域失败只影响这个领域的 teacher。
Stage 3 再统一做蒸馏集成。
对于工业 post-training，这种 workflow 解耦可能和 benchmark 提升一样重要。

展开页面内容时，可以按这个顺序讲：Discussion §5 Discussion：组织工程价值 workflow Parallel development 各领域团队并行迭代 reward、data、sandbox。；recipe Recipe decoupling 每个领域可选不同 RL 算法、采样轨迹（rollout）过程和超参。；risk Risk isolation 单域失败只重启单域 teacher，不拖垮全局 run。；工程结论：先分领域生产能力，再用统一学生模型吸收这些能力。。## Slide 66: 结论与可讨论点

### 页面内容覆盖
- Conclusion §6 结论与可讨论点 Takeaways policy-space capability integration on-policy student 采样轨迹（rollouts） dense token-level teacher signal same-origin teacher stability 可以讨论 更多 domain 下 prefill 成本是否仍可隐藏？ 跨领域 prompt 如何 routing？ 能否安全利用外部强 teacher？ 多轮 MOPD 是否会放大偏差？

### 扩写讲稿
最后总结论文贡献。
MOPD 提出的是一种 policy-space capability integration 范式：student 在自己的轨迹上采样，每个 prompt 按领域路由到冻结 teacher，teacher 提供 dense token-level log-probability 信号，student 通过 reverse KL 吸收多个 teacher 的能力。
可以留几个讨论问题：第一，如果 domain 数量更多，teacher prefill 的吞吐和调度还能否隐藏开销？
第二，现实 prompt 常常跨领域，domain router 如何处理混合任务？
第三，same-origin 假设限制了外部强 teacher 的使用，能否通过 bridge model 或 KL warmup 缓解？
第四，多轮 MOPD 是否会累积偏差或造成某些能力过拟合？
这里的关键不是判断某类训练一定好或一定差，而是说明训练轨迹和推理轨迹是否一致。MOPD 选择 student 采样轨迹（rollout），是为了让 teacher 的监督落在 student 实际会到达的前缀上。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：Conclusion §6 结论与可讨论点 Takeaways policy-space capability integration on-policy student 采样轨迹（rollouts） dense token-level teacher signal same-origin teacher stability 可以讨论 更多 domain 下 prefill 成本是否仍可隐藏？ 跨领域 prompt 如何 routing？ 能否安全利用外部强 teacher？ 多轮 MOPD 是否会放大偏差？。## Slide 67: 7. Writing

### 页面内容覆盖
- 7. Writing
- Abstract 与 Introduction 结构拆解
- 最后按段落分析论文开头的组织结构。

### 扩写讲稿
方法、实验和分析已经收束，接下来进入 Writing 部分。
前面已经讲完 MOPD 的方法、实验和分析；最后这部分只分析 Abstract 和 Introduction 的段落结构。
每页左侧保留论文原文，右侧给出段意和组织结构。
原文中的关键句使用不同颜色高亮，右侧组织结构使用同色标签对应，方便听众快速从结构说明回到原句。

## Slide 35: Writing：Abstract 结构

### 页面内容覆盖
- Writing · Abstract
- Abstract：问题、方法、机制、证据
- 原文高亮：多能力集成（capability integration）困难；已有方法低效或损失性能；提出 MOPD；消除 exposure bias 并提供 dense signal；部署到 MiMo-V2-Flash。
- 段意：这一段先指出多能力集成（capability integration）困难，再举 Off-Policy Finetune 和 Mix-RL 说明已有路线存在效率或性能损失；随后提出 MOPD，说明它用领域 teacher 和 student 自身采样轨迹（rollouts）完成蒸馏；最后用 Qwen3-30B-A3B 对比实验和 MiMo-V2-Flash 部署说明方法的实验与实践证据。
- 组织结构：问题 → 限制 → 方法 → 机制 → 证据。

### 扩写讲稿
这里看 Abstract 的结构。
蓝色高亮对应问题：多能力集成（capability integration）到一个模型仍然困难。
橙色高亮对应已有方法限制：Off-Policy Finetune 和 Mix-RL 代表的路线存在效率或性能问题。
绿色高亮对应方法：提出 Multi-teacher On-Policy Distillation，并简述先训练领域教师、再在学生 采样轨迹（rollout）上蒸馏。
粉色高亮对应机制：消除 exposure bias，并提供 dense optimization signal。
紫色高亮对应证据：Qwen3-30B-A3B 的对比结果和 MiMo-V2-Flash 的工业部署。
因此这一段的结构是：问题、限制、方法、机制、证据。

## Slide 36: Writing：Introduction 第 1 段

### 页面内容覆盖
- Writing · Introduction P1
- 第 1 段：从领域趋势引出核心问题
- 原文高亮：RL 是重要后训练方法；不同任务域依赖不同 RL pipeline；每条 pipeline 能提升目标领域；最终需要一个跨领域统一模型；构建这种模型仍是 open problem。
- 段意：这一段先说明 RL 已经成为 LLM 后训练的重要方法；接着举数学、软件工程、指令跟随与创意写作、搜索智能体等例子，说明不同能力依赖不同 RL pipeline；然后指出这些单域 pipeline 各自有效；最后把问题推进到“如何得到一个跨领域都强的单一模型”。
- 组织结构：背景 → 分化 → 局部有效 → 目标 → 问题。

### 扩写讲稿
这里看 Introduction 第一段。
蓝色高亮对应背景：RL 已经成为提升 LLM 能力的重要方法。
橙色高亮对应领域分化：不同任务域依赖不同 RL pipeline。
这一段列出数学、软件工程、指令跟随、创意写作和搜索智能体，说明这些领域的训练流程并不相同。
绿色高亮对应局部有效：每条 pipeline 能提升目标领域能力。
粉色高亮对应目标：最终需要一个跨领域表现都好的单一模型。
紫色高亮对应问题：构建这种模型仍是现代 LLM 后训练中的 open problem。

## Slide 37: Writing：Introduction 第 2 段

### 页面内容覆盖
- Writing · Introduction P2
- 第 2 段：系统排除已有路线
- 原文高亮：已有方法分为四类；Mix-RL 存在跨域信号干扰；Cascade RL 存在早期能力衰减；Off-Policy Finetune 引入 exposure bias；最后归纳为没有 satisfactory middle ground。
- 段意：这一段举了四类已有能力集成（capability integration）路线：Mix-RL、Cascade RL、Off-Policy Finetune 和 Param-Merge；分别说明它们对应跨域信号干扰、顺序训练退化、off-policy exposure bias 和权重空间融合（weight-space merging）不稳定；最后把这些问题概括为学习效率、能力峰值和训练稳定性之间的取舍。
- 组织结构：分类 → 干扰 → 退化 → 错位 → 归纳。

### 扩写讲稿
这里看 Introduction 第二段。
蓝色高亮对应分类：已有 capability-integration 方法被分成四类。
橙色高亮对应 Mix-RL 的问题：cross-domain training signals interfere。
绿色高亮对应 Cascade RL 的问题：earlier-stage capabilities may decay。
粉色高亮对应 Off-Policy Finetune 的问题：off-policy supervision induces exposure bias。
紫色高亮对应段末归纳：这些方法在 learning efficiency、attainable peak 和 training stability 之间取舍，没有 satisfactory middle ground。
这一段的结构是分类、列举失败机制、再给出总括性缺口。

## Slide 38: Writing：Introduction 第 3 段

### 页面内容覆盖
- Writing · Introduction P3
- 第 3 段：提出方法并给出结构性收益
- 原文高亮：提出 MOPD；在 policy space 而非 weight/static dataset space 集成；先独立训练领域 teacher；列出三条结构性收益；student 采样轨迹（rollout）对应 exposure bias。
- 段意：这一段先提出 MOPD，并说明它在 policy space 做多教师能力集成（capability integration）；随后交代流程：每个领域独立训练 teacher，再把 teacher 能力蒸馏到一个 student；最后列出三类收益，分别对应稠密 teacher 信号、student 自身采样轨迹（rollout）分布和按 prompt 路由的 policy-space 集成。
- 组织结构：提出 → 空间 → 流程 → 收益 → 对应。

### 扩写讲稿
这里看 Introduction 第三段。
蓝色高亮对应方法提出：we propose MOPD。
橙色高亮对应集成空间：policy space，而不是 weight space 或 static dataset space。
绿色高亮对应流程：先在每个领域独立做 specialised RL，得到 domain teachers，再蒸馏到单一 student。
粉色高亮对应结构收益的总起：This design has three structural benefits。
紫色高亮对应其中一个关键收益：training runs entirely on the student’s own rollout distribution，用于处理 exposure bias。
该段把方法名称、方法空间、训练流程和收益对应关系放在一个段落中。

## Slide 39: Writing：Introduction 第 4 段

### 页面内容覆盖
- Writing · Introduction P4
- 第 4 段：实验范围与证据类型
- 原文高亮：两个不同规模和架构的 base models；与四类 baselines 比较；normalised score 领先 5.5；部署到 MiMo-V2-Flash；same-origin teachers 对稳定优化关键。
- 段意：这一段先说明实验覆盖两个不同规模和架构的 base model；接着列出 Mix-RL、Cascade RL、Off-Policy Finetune、Param-Merge 等 baseline，说明比较对象完整；然后给出 Qwen3-30B-A3B 上领先 5.5 分的主结果；最后补充 MiMo-V2-Flash 工业部署和 Top-k、same-origin、多轮迭代等机制分析。
- 组织结构：范围 → 对比 → 结果 → 部署 → 分析。

### 扩写讲稿
这里看 Introduction 第四段。
蓝色高亮对应实验范围：two base models of different scales and architectures。
橙色高亮对应对比对象：Mix-RL、Cascade RL、Off-Policy Finetune、Param-Merge 和 MOPD。
绿色高亮对应主结果：normalised score 上领先最强 baseline 5.5 points。
粉色高亮对应工业部署：MiMo-V2-Flash。
紫色高亮对应机制分析：same-origin teachers 对 stable optimization 关键。
这一段的结构是实验范围、baseline 对比、主结果、工业部署和补充分析。

## Slide 40: Writing：Introduction 第 5 段

### 页面内容覆盖
- Writing · Introduction P5
- 第 5 段：贡献列表
- 原文高亮：提出 MOPD；student 采样轨迹（rollout）上的 dense token-level supervision；在 Qwen3-30B-A3B 上验证；MiMo-V2-Flash 工业规模验证。
- 段意：这一段用两条 contribution 收束全文：第一条概括方法本身，即 MOPD 通过 student 自身采样轨迹（rollouts）上的 dense token-level supervision 做多教师能力集成（capability integration）；第二条概括验证范围，即在 Qwen3-30B-A3B 上做 baseline 对比，并进一步应用到工业规模 MiMo-V2-Flash。
- 组织结构：方法 → 机制 → 验证 → 扩展。

### 扩写讲稿
这里看 Introduction 最后一段。
蓝色高亮对应方法：We propose MOPD。
橙色高亮对应机制：dense, token-level supervision delivered on the student’s own rollouts。
绿色高亮对应验证：We validate MOPD on Qwen3-30B-A3B。
粉色高亮对应扩展：industrial-scale MiMo-V2-Flash。
该段用两条 contribution 概括方法和验证范围。

## Slide 41: 谢谢

### 页面内容覆盖
- 谢谢 MOPD 的核心：用同源多教师，在 student 自身轨迹上做稠密蒸馏。

### 扩写讲稿
结尾页。
可以停在这里进入 Q&A。
同源假设需要讲成稳定性条件：teacher 和 student 从同一 SFT checkpoint 出发，初始分布距离较小，teacher 在 student 采样轨迹（rollout）上给出的概率信号更平滑。
展开页面内容时，可以按这个顺序讲：谢谢 MOPD 的核心：用同源多教师，在 student 自身轨迹上做稠密蒸馏。。最后收束到整篇论文的主线：MOPD 用在线轨迹、教师打分和策略空间蒸馏完成多能力集成（capability integration）。
