# MOPD 全技术细节核对版

本文档用于对照 `2606.30406v1.pdf` 检查组会讲解是否覆盖全部关键技术细节。建议和动态 slides 一起使用：slides 负责讲解节奏和图示，本文档负责兜底核对。

## 随文旁注术语索引

动态 slides 已把这些背景知识分散到对应论文内容页：术语首次出现时用右下角旁注解释，主线仍按论文顺序推进。本节只作为复习索引。

### Post-training

预训练后的继续训练阶段，目标是把 base model 变成更可用、更符合任务需求的模型。常见流程是：

1. Pretraining：大规模 next-token prediction，学语言、知识和通用模式。
2. SFT：用高质量指令-答案对教模型按要求回答。
3. RL / Preference optimization：用 reward、偏好或可验证信号进一步推高目标能力。
4. Capability integration：把多个单域能力合到一个统一模型。

### SFT

SFT 是 supervised fine-tuning。给定 prompt `x` 和目标答案 `y*`，训练模型提高目标答案每个 token 的概率：

```tex
\mathcal{L}_{\mathrm{SFT}}(\theta)=-\sum_t \log \pi_\theta(y_t^{\star}\mid x,y_{<t}^{\star})
```

在本文中，SFT checkpoint 同时初始化 Stage-2 teachers 和 Stage-3 student，因此是 same-origin teacher stability 的来源。

### Policy

语言模型里的 policy `πθ` 就是“给定上下文时下一个 token 的概率分布”：

```tex
\pi_\theta(v\mid x,y_{<t})
```

其中 `v` 是候选 token，`x` 是 prompt，`y_<t` 是已经生成的前缀。

### Logits / probability / log-prob

模型先输出 logits `z`，通过 softmax 得到 token 概率：

```tex
p(v)=\mathrm{softmax}(z)_v
```

训练和蒸馏中常用 `log p(v)`，也就是 log-prob。MOPD 的 teacher prefill 返回的核心信号就是 student 轨迹上每个 token 的 teacher log-prob 或 top-k logits。

### Rollout / trajectory

Rollout 是强化学习术语，指当前 policy 采样出的一条完整行为轨迹。在 LLM 中就是：

```text
prompt x → y1 → y2 → ... → yn
```

MOPD 的关键是 `y ~ πθ`，即回答由 student 当前策略自己生成，teacher 离线答案不作为训练轨迹。

### Teacher / student distillation

Teacher 是提供训练信号的模型，student 是被更新、最终部署的模型。传统蒸馏常让 student 模仿 teacher 输出；MOPD 则让 student 自己 rollout，teacher 只在该 rollout 上 scoring。

### On-policy / off-policy

- On-policy：训练样本来自当前要更新的 policy，例如 MOPD 中 `y ~ πθ`。
- Off-policy：训练样本来自其他 policy 或固定数据，例如在 teacher rollouts 上做 SFT。

这一区别解释了为什么 Off-Policy Finetune 会有 exposure bias，而 MOPD 可以构造上避免。

### KL divergence

KL 衡量两个分布差异：

```tex
\mathrm{KL}(P\Vert Q)=\sum_v P(v)\log\frac{P(v)}{Q(v)}
```

MOPD 用 reverse KL：

```tex
P=\pi_\theta,\quad Q=\pi_{\phi^d}
```

也就是惩罚 student 当前会选择、但 teacher 不认可的 token。

### PPO / GRPO / advantage

PPO 和 GRPO 都是常见 on-policy RL 优化方法。Advantage 表示某个 action/token 比当前基线好多少。在 MOPD 的 PG 实现中，advantage 直接由 teacher-student log-prob gap 给出：

```tex
\hat A_{\mathrm{MOPD},t}=\operatorname{sg}\left[\log\pi_{\phi^d}(y_t)-\log\pi_\theta(y_t)\right]
```

## 公式渲染说明

动态 slides 中的数学公式已改为 MathJax 输入格式，即 `\(...\)` 和 `\[...\]`。打开 HTML 时会通过 MathJax 渲染公式；如果离线无法加载 MathJax，页面仍会显示原始 TeX 公式文本。

## 论文核心问题

现代 LLM post-training 会用 RL 推高特定能力，但不同能力通常依赖不同 RL pipeline：

- 数学推理：verifiable-answer RL / RLVR。
- 软件工程：executable sandbox 中的 agent-style RL。
- 指令跟随与创意写作：rubric-based RL。
- 搜索型 agent：web-environment RL。

单域 RL 可以得到强 domain expert，但最终需要一个统一模型。论文把这个问题定义为 capability integration，而不是单域能力提升。

## 四类已有方法

| 方法 | 机制 | Dense | On-policy | Parallelisable | 论文指出的问题 |
|---|---|---:|---:|---:|---|
| Param-Merge | 平均 teacher weights 或 task arithmetic | 否 | 不适用 | 是 | weight-space 参数冲突，recipe/系数敏感，不能稳定匹配所有 teacher |
| Off-Policy Finetune | 在 teacher rollouts 上对 student 做离线 SFT | 是 | 否 | 是 | teacher trajectory 与 student inference trajectory 不一致，产生 exposure bias |
| Mix-RL | 多域 prompt 池化到同一 RL batch，每条样本用自己的 reward/advantage | 否 | 是 | 否 | 跨域训练信号干扰，see-saw effect，joint model 低于 per-domain teachers |
| Cascade RL | 按领域顺序做 RL，论文默认 IF→Math→SWE | 否 | 是 | 否 | 后续领域可能损伤早期领域，长链路放大稳定性风险 |
| MOPD | 多 teacher 在 student 自己 rollouts 上做 token-level on-policy distillation | 是 | 是 | 是 | 论文提出的方法 |

## MOPD 三阶段 pipeline

### Stage 1: General SFT

- 先在覆盖所有目标能力的 broad corpus 上 fine-tune base model。
- 得到 SFT checkpoint。
- 这个 checkpoint 同时用于：
  - Stage 2 每个 domain teacher 的初始化。
  - Stage 3 MOPD student 的初始化。
- 这为 same-origin teacher stability 提供基础。

### Stage 2: Domain-specialised RL training

- 对每个领域 `d`，从 Stage-1 SFT checkpoint 出发训练 teacher `πϕᵈ`。
- 每个领域可使用最适合自己的 RL recipe：
  - Math: verifiable-answer RL。
  - SWE: executable-sandbox agent RL。
  - IF: benchmark/rubric style RL。
- 各领域训练相互独立，可完全并行。

### Stage 3: MOPD

teacher 冻结，student 从 Stage-1 SFT checkpoint 初始化。每个 optimization step：

1. 从 multi-domain dataset 采样 prompt batch。
2. student 对每个 prompt 生成 trajectory，并记录沿 trajectory 的 per-token probability distribution。
3. 按 task domain 把 trajectory dispatch 给对应 teacher。
4. teacher 对 student trajectory 做 prefill，得到每个 token 位置的 teacher probability distribution / log-probabilities / top-k logits。
5. 沿 trajectory 最小化 student 与 teacher 的 per-token reverse KL。

输出是一个统一 student model，吸收多个 domain teachers 的能力。

## MOPD 五个结构性优势

1. No exposure bias：student 在自己的 rollouts 上训练，训练和推理的 state distribution 构造上匹配。
2. Dense per-token supervision：teacher 在 trajectory 的每个 token 位置提供 probability distribution，比 trajectory-level reward 更密集，方差更低，样本效率更高。
3. Stable integration in policy space：通过 prompt routing 使用对应 teacher，不在 weight space 做 averaging 或 task arithmetic，避免权重融合不稳定。
4. Modular and parallel teachers：teacher RL training 可并行，每个 teacher 有自己的 hyperparameter configuration；某一领域失败或调参不影响其他 teacher。
5. Same-origin teacher stability：teacher 和 student 都来自同一 SFT checkpoint，policy distribution 接近，initial KL 低，distillation 更稳定。

## Reverse KL 目标

Stage 3 优化 per-token reverse KL：

```text
L_rev-KL = E_{x, y~πθ} [ (1/|y|) Σ_t Σ_v πθ(v) log(πθ(v) / πϕᵈ(v)) ]
```

其中：

- `πϕᵈ` 是 prompt `x` 对应 domain `d` 的 dispatched teacher。
- `πθ(v)` 是 `πθ(v | x, y_<t)` 的简写。
- `πϕᵈ(v)` 是 `πϕᵈ(v | x, y_<t)` 的简写。
- 外层 `y~πθ` 表示 trajectory 来自 student，因此是 on-policy。
- `Σ_t` 表示每个 token 位置都有监督。
- `Σ_v` 表示在词表 distribution 上比较 student 与 teacher。

Reverse KL 的重点是期望在 student 当前分布上，适合 “student samples, teacher scores” 的 on-policy distillation。

## Policy-gradient 实现

论文沿用 MiniLLM 思路，把 reverse KL 写成 policy-gradient 形式。梯度等价于用 teacher-student log difference 作为 per-token advantage：

```text
Â_MOPD,t = sg[ log πϕᵈ(y_t) - log πθ(y_t) ]
```

训练稳定性处理：

```text
Â^clip_MOPD,t = clip(Â_MOPD,t, -A_max, +A_max)
```

最终 loss：

```text
L^PG_MOPD(θ) = - E_{x,y} [ (1/|y|) Σ_t Â^clip_MOPD,t log πθ(y_t) ]
```

解释：

- teacher 比 student 更认可 sampled token，则 advantage 为正，提高该 token 概率。
- teacher 比 student 更不认可 sampled token，则 advantage 为负，压低该 token 概率。
- 默认 `A_max=5`。
- 这个形式可直接接入 PPO/GRPO 框架，唯一改动是 advantage computation。

## Top-k distillation 实现

PG 形式每个位置只利用 sampled token。Top-k 形式利用 teacher 在该位置的 top-k tokens，降低方差并利用更多 teacher distribution 信息。

定义：

```text
T_t^d = TopK_k(πϕᵈ(· | x, y_<t))
```

loss：

```text
L^TopK_MOPD(θ)
= E_{x,y} [ (1/|y|) Σ_t Σ_{v∈T_t^d}
  πθ(v) log(πθ(v)/πϕᵈ(v)) - πθ(v) + πϕᵈ(v)
]
```

关键细节：

- 默认 `k=64`。
- 相比标准 reverse KL，多了 `πϕᵈ(v) - πθ(v)` correction term。
- 这个 correction 修正 top-k 截断带来的 bias，保证在 top-k tokens 上 loss 在 `πθ=πϕᵈ` 处最小。
- 如果没有 correction，naive top-k-truncated reverse KL 不具备这个性质。
- 工程上，它只需传输 top-k logits/log-probs，避免 full-vocabulary distillation 的巨大 payload。

## Teacher prefill infrastructure

Stage 3 的额外操作是 teacher prefill：

- 每条 student rollout 送到 dispatched teacher。
- teacher 返回 per-token log-probabilities 或 top-k logits。

论文没有把 teacher prefill 串行塞进 RL trainer，而是：

- 每个 domain teacher 作为独立 prefill service。
- student sampler 持续生成 rollouts。
- 一条 sequence 生成结束后，trainer 异步向 teacher service 发 prefill request。
- teacher prefill 与其他 sequence sampling overlap。
- wall-clock critical path 主要由 sampling 决定。
- 论文部署中 teacher 几乎没有可测 wall-clock overhead。

## Controlled experiment 设置

### Base / SFT

- 起点：`Qwen3-30B-A3B-Base`。
- 先用覆盖目标领域的 broad-coverage corpus 做 SFT。
- 所有 baselines 和 MOPD 都从同一个 SFT checkpoint 出发。

### Domains / Benchmarks

- Math：AIME25、AIME26。
- Instruction Following：IFBench、IFEval。
- Software Engineering：SWE-bench Verified。

### Baselines

- Mix-RL：联合多域 RL。
- Cascade RL：按领域顺序 RL，顺序为 IF→Math→SWE。
- Off-Policy Finetune：在 Stage-2 teachers 的 rollouts 上离线 SFT。
- Param-Merge：包括平均合并与 Task Arithmetic。
- MOPD：论文方法。

## Normalised score

不同领域 absolute headroom 不同，因此论文使用 normalised score。

对每个领域 `d`：

```text
s̃_d = (s_d - s_d^s) / (s_d^t - s_d^s)
```

其中：

- `s_d^s`：Stage-1 SFT student 在领域 `d` 的准确率。
- `s_d^t`：对应 Stage-2 specialist teacher 的准确率。
- `s_d`：某个 integration method 的准确率。

解释：

- `0` 表示等于 SFT。
- `1` 表示等于 domain teacher。
- `>1` 表示超过 teacher。
- `<0` 表示比 SFT 退化。
- headline score 是对各 domain 的 uniform average。

## Table 2 主结果

| Method | AIME25 | AIME26 | IFBench | IFEval | SWE-bench Verified | Norm |
|---|---:|---:|---:|---:|---:|---:|
| Student (SFT-only) | 45.42 | 54.48 | 42.69 | 84.17 | 35.80 | 0.0000 |
| RL Teacher | 54.79 | 63.65 | 78.40 | 95.50 | 51.20 | 1.0000 |
| Mix-RL | 52.71 | 63.75 | 75.00 | 94.58 | 48.80 | 0.8818 |
| Cascade RL | 48.54 | 61.88 | 77.11 | 95.80 | 47.80 | 0.7752 |
| Off-Policy Finetune | 51.56 | 63.44 | 80.95 | 93.35 | 45.80 | 0.8241 |
| Param-Merge Avg | 47.81 | 59.58 | 53.74 | 88.79 | 39.60 | 0.3280 |
| Param-Merge Task Arith. | 49.38 | 63.96 | 78.23 | 95.81 | 48.80 | 0.8574 |
| MOPD | 51.46 | 65.31 | 77.89 | 93.84 | 50.40 | 0.9373 |
| Δ(MOPD - RL Teacher) | -3.33 | +1.66 | -0.51 | -1.66 | -0.80 | -0.0627 |

四个观察：

1. Mix-RL、Cascade RL、Off-Policy FT 都有各自 domain-specific gap。
2. MOPD 最高且最均衡，norm score 0.9373，比 Mix-RL 0.8818 高 0.0555。
3. MOPD 三个 per-domain normalised scores 落在 `[0.91, 0.95]`，range 0.044。
4. Param-Merge 对 recipe 极敏感：Avg 只有 0.3280，Task Arithmetic 回升到 0.8574，但 domain profile 不稳定。

## Figure 2 训练动态

- MOPD 在 IF 上约 25K IF samples 达到 teacher-level plateau。
- MOPD 在 SWE 上约 30K SWE samples 达到 plateau。
- Mix-RL 需要完整 150K–180K per-domain sample budget 才接近类似水平。
- 原因是 teacher dense per-token supervision 比 trajectory-level RL reward 提供更丰富梯度信号。

## MiMo-V2-Flash scaling

论文把完整三阶段 pipeline 应用到工业级 `MiMo-V2-Flash`，这是 309B 参数模型。

覆盖 domain teachers：

- Math。
- Code。
- Instruction Following。
- SWE。
- Tool Use。

Table 3：

| Metric | AIME25 | HMMT25 | LCB | IFBench | SWE-Bench V. | τ²-Bench | τ²-Telecom |
|---|---:|---:|---:|---:|---:|---:|---:|
| Student | 89.3 | 76.9 | 77.5 | 55.4 | 67.8 | 75.9 | 92.7 |
| Teacher | 93.9 | 82.6 | 82.6 | 68.9 | 74.2 | 79.6 | 95.0 |
| MOPD | 94.1 | 84.4 | 83.2 | 66.7 | 73.4 | 80.3 | 95.3 |
| Δ | +0.2 | +1.8 | +0.6 | -2.2 | -0.8 | +0.7 | +0.3 |

MOPD 在多数 benchmark 上匹配或超过 teacher；IFBench 和 SWE-Bench Verified 有小幅回退。

## Analysis 1: PG vs Top-k

设置：

- 同样 Qwen3-30B-A3B pipeline。
- same teachers、same data budget、same hyperparameters。
- Top-k variant 使用 `k=64`。

结果：

| Math Teacher | Loss Variant | AIME25 | AIME26 | IFBench | IFEval | SWE | Norm |
|---|---|---:|---:|---:|---:|---:|---:|
| RL Teacher | Policy gradient | 51.46 | 65.31 | 77.89 | 93.84 | 50.40 | 0.9373 |
| RL Teacher | Top-k distillation | 51.77 | 64.79 | 75.85 | 93.07 | 50.20 | 0.9093 |

Figure 3 same-origin runs：

- Math accuracy smooth climb。
- Per-token reverse KL 从约 0.04 单调下降。
- Policy entropy 稳定在约 0.30。

结论：same-origin teacher 下 PG 已足够稳定，Top-k 没带来明显额外稳定性或方差降低。

## Analysis 2: Same-origin teacher stability

实验：

- 只替换 Math teacher。
- 把默认 Qwen3-30B-A3B Math RL teacher 换成更强但分布不同的 `Qwen3-235B-A22B`。
- IF/SWE teachers、数据、超参都保持不变。

结果：

| Math Teacher | Loss Variant | AIME25 | AIME26 | IFBench | IFEval | SWE | Norm |
|---|---|---:|---:|---:|---:|---:|---:|
| Qwen3-235B-A22B | Policy gradient | 45.63 | 51.56 | 79.25 | 93.99 | 50.60 | 0.6003 |
| Qwen3-235B-A22B | Top-k distillation | 0.94 | 0.42 | 72.96 | 88.97 | 51.20 | -1.1898 |

机制：

- 外部 teacher 初始 per-token KL 约 0.19。
- same-origin 初始 KL 约 0.04。
- 差距约 5 倍。
- PG 下 math accuracy 逐步退化，entropy 从 0.30 收缩到 0.21。
- Top-k 下 step 18 附近 catastrophic collapse，KL 和 entropy 剧烈振荡。

结论：teacher 更强不代表更适合 on-policy distillation。policy distribution 对齐是稳定性的关键。

## Analysis 3: Multi-round student-teacher evolution

设置：

- 第一轮 MOPD 后，把 Iter-1 student 作为下一轮 per-domain RL teacher 的初始化。
- 第二轮只对 Math 和 IF 做 RL training 和 MOPD distillation。
- SWE 不训练新 teacher，也不做 distillation；SWE 分数只反映间接影响。

Table 5：

| Round | AIME25 | AIME26 | IFBench | IFEval | SWE-bench Verified | Norm |
|---|---:|---:|---:|---:|---:|---:|
| Iter 1 MOPD | 51.46 | 65.31 | 77.89 | 93.84 | 50.40 | 0.937 |
| Iter 2 RL Teacher | 54.27 | 65.52 | 81.46 | 95.65 | 50.40 | 1.030 |
| Iter 2 MOPD | 53.44 | 64.90 | 79.76 | 95.44 | 50.20 | 0.986 |

结论：

- Iter-2 RL teacher 比 Iter-1 MOPD 更强，说明单轮 MOPD 后仍有 domain headroom。
- Iter-2 MOPD 从 0.937 提升到 0.986，说明 pipeline 可迭代吸收更强 teacher。

## Appendix A: 训练数据

| Domain | SFT data | RL data | Max length |
|---|---|---|---|
| Math | Mixture-of-Thoughts math subset | BigMath、ORZ 等开源数据收集过滤 | 32,768 |
| IF | 按 IFBench 方法构造 prompts，并在 gpt-oss-120b 上蒸馏 | 按 IFBench recipe 合成 | 32,768 |
| SWE | R2E-Gym tasks，经开源模型蒸馏 | R2E-Gym-Lite | 65,536；最多 50 interaction turns |

## Appendix A: 训练超参

- RL 算法：on-policy GRPO。
- 使用 Dynamic Sampling：rollout 产生的数据只做一次 gradient update，然后丢弃。
- Per-domain RL：
  - Learning rate：`3 × 10^-6`。
  - Math / IF：BS=144，N=8，约 175K sequences。
  - SWE：BS=80，N=8，约 150K sequences。
- Cascade RL：
  - 同 per-domain RL 配置。
  - 顺序：IF→Math→SWE。
- Mix-RL：
  - Learning rate：`4 × 10^-6`。
  - BS=256，N=8。
  - Per-batch domain ratio：Math : IF : SWE = 0.35 : 0.35 : 0.30。
- MOPD：
  - 不使用 Dynamic Sampling。
  - BS=2048，N=1。
  - Per-batch domain ratio：Math : IF : SWE = 0.35 : 0.35 : 0.30。
  - PG 默认 `A_max=5`。
  - Top-k 默认 `k=64`。

## Appendix B: 评测协议

- AIME25 / AIME26：
  - 每题采样 32 次。
  - 报告 avg@32。
  - 目的是降低低样本高难数学评测的方差。
- IFBench / IFEval：
  - 每个问题评测 1 次。
- SWE-bench Verified：
  - 每个任务评测 1 次。
- 所有 benchmark：
  - Sampling temperature = 1.0。
  - 不使用 top-p truncation。
  - 不使用 top-k truncation。

## 组会讲解建议

- Introduction：重点讲“能力集成”不同于“单域能力提升”。
- Method：重点讲 Stage 3 的 teacher 是 scorer，不是 generator。
- Formula：重点讲 reverse KL 的期望在 student rollout 上。
- PG：重点讲 teacher-student log gap 如何变成 advantage。
- Top-k：重点讲 correction term 解决截断 bias。
- Experiments：重点讲 normalised score 和 per-domain headroom。
- Analysis：重点讲 same-origin 比 teacher absolute strength 更关键。
- Appendix：至少点出训练超参和评测协议，避免听众质疑实验公平性。
